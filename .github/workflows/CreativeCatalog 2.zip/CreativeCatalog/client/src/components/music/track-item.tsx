import { Play, Pause, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import Waveform from "./waveform";
import type { TrackWithArtist } from "@shared/schema";

interface TrackItemProps {
  track: TrackWithArtist;
  isCurrentTrack: boolean;
  isPlaying: boolean;
  onPlay: () => void;
}

export default function TrackItem({ track, isCurrentTrack, isPlaying, onPlay }: TrackItemProps) {
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="track-item flex items-center p-4 rounded-lg hover:bg-bb-gray transition-colors group cursor-pointer">
      <div className="flex items-center flex-1" onClick={onPlay}>
        <Button
          className={`play-button w-10 h-10 rounded-full flex items-center justify-center mr-4 p-0 ${
            isCurrentTrack ? 'bg-bb-pink' : 'bg-bb-purple'
          }`}
          onClick={(e) => {
            e.stopPropagation();
            onPlay();
          }}
        >
          {isCurrentTrack && isPlaying ? (
            <Pause className="w-4 h-4 text-white" />
          ) : (
            <Play className="w-4 h-4 text-white ml-1" />
          )}
        </Button>
        
        <div className="w-16 h-8 mr-4">
          <Waveform isPlaying={isCurrentTrack && isPlaying} compact />
        </div>
        
        <div className="flex-1">
          <h4 className={`font-semibold transition-colors ${
            isCurrentTrack ? 'text-bb-purple' : 'text-white group-hover:text-bb-purple'
          }`}>
            {track.title}
          </h4>
          <p className="text-gray-400 text-sm">{track.artist.name}</p>
        </div>
        
        <div className="text-gray-400 text-sm mr-4">
          {track.album?.title || "Single"}
        </div>
        <div className="text-gray-400 text-sm w-16 text-right">
          {track.duration ? formatDuration(track.duration) : "0:00"}
        </div>
      </div>
      
      <Button
        variant="ghost"
        size="icon"
        className={`opacity-0 group-hover:opacity-100 transition-opacity ml-4 ${
          track.isLiked ? 'text-bb-pink' : 'text-gray-400 hover:text-bb-purple'
        }`}
      >
        <Heart className={`w-4 h-4 ${track.isLiked ? 'fill-current' : ''}`} />
      </Button>
    </div>
  );
}
