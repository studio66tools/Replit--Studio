interface WaveformProps {
  isPlaying: boolean;
  compact?: boolean;
}

export default function Waveform({ isPlaying, compact = false }: WaveformProps) {
  const heights = compact 
    ? [12, 24, 16, 32, 20, 28, 18, 22]
    : [8, 16, 12, 24, 14, 20, 10, 18];

  return (
    <div className={`waveform ${compact ? 'h-8' : 'h-10'}`}>
      {heights.map((height, index) => (
        <div
          key={index}
          className={`wave-bar ${isPlaying ? '' : 'opacity-60'}`}
          style={{ height: `${height}px` }}
        />
      ))}
    </div>
  );
}
