import { Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Artist } from "@shared/schema";

interface ArtistCardProps {
  artist: Artist;
  onPlay: () => void;
}

export default function ArtistCard({ artist, onPlay }: ArtistCardProps) {
  return (
    <div className="bg-bb-dark rounded-xl p-6 card-hover cursor-pointer group">
      <div className="relative mb-4">
        <img 
          src={artist.imageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"}
          alt={`${artist.name} - Artist`}
          className="w-full h-48 object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bb-purple/60 to-transparent rounded-lg" />
        <Button
          className="play-button absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-bb-purple rounded-full hover:scale-110 transition-transform p-0"
          onClick={(e) => {
            e.stopPropagation();
            onPlay();
          }}
        >
          <Play className="w-5 h-5 text-white ml-1" />
        </Button>
      </div>
      <h4 className="text-xl font-bold mb-2">
        {artist.emoji} {artist.name}
      </h4>
      <p className="text-gray-400 text-sm">{artist.bio}</p>
    </div>
  );
}
