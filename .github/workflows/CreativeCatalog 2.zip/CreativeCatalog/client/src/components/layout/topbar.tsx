import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  ChevronLeft, 
  ChevronRight, 
  Search,
  Bell
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { TrackWithArtist } from "@shared/schema";

export default function TopBar() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: searchResults = [] } = useQuery<TrackWithArtist[]>({
    queryKey: ['/api/search/tracks', { q: searchQuery }],
    enabled: searchQuery.length > 0,
  });

  return (
    <header className="bg-bb-dark border-b border-bb-gray p-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-bb-gray hover:bg-bb-purple"
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-bb-gray hover:bg-bb-purple"
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>
      
      <div className="flex-1 max-w-md mx-4 relative">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search artists, tracks, albums..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-bb-gray border-bb-gray rounded-full px-4 py-2 pl-10 text-white placeholder-gray-400 focus:border-bb-purple"
          />
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
        
        {/* Search Results Dropdown */}
        {searchQuery && searchResults.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-bb-dark border border-bb-gray rounded-lg shadow-lg z-50 max-h-60 overflow-y-auto">
            {searchResults.map((track) => (
              <div 
                key={track.id}
                className="p-3 hover:bg-bb-gray cursor-pointer border-b border-bb-gray last:border-b-0"
              >
                <div className="font-medium text-white">{track.title}</div>
                <div className="text-sm text-gray-400">{track.artist.name}</div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full hover:bg-bb-gray"
        >
          <Bell className="w-4 h-4" />
        </Button>
        <div className="w-8 h-8 bg-gradient-to-r from-bb-purple to-bb-pink rounded-full" />
      </div>
    </header>
  );
}
