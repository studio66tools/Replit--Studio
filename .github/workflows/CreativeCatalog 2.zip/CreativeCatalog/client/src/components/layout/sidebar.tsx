import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { 
  Home, 
  Search, 
  Music, 
  Heart,
  Mic,
  Download,
  BarChart3,
  Zap
} from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Playlist } from "@shared/schema";

export default function Sidebar() {
  const [location] = useLocation();

  const { data: playlists = [] } = useQuery<Playlist[]>({
    queryKey: ['/api/playlists'],
  });

  const navItems = [
    { path: "/", label: "Home", icon: Home },
    { path: "/search", label: "Search", icon: Search },
    { path: "/library", label: "Your Library", icon: Music },
    { path: "/liked", label: "Liked Songs", icon: Heart },
    { path: "/studio", label: "Studio Booking", icon: Mic },
    { path: "/licensing", label: "Music Licensing", icon: Download },
    { path: "/analytics", label: "Analytics & IP", icon: BarChart3 },
    { path: "/vip-distribution", label: "VIP Distribution", icon: Zap },
  ];

  return (
    <aside className="w-64 bg-bb-dark border-r border-bb-gray flex flex-col">
      {/* Logo Section */}
      <div className="p-6 border-b border-bb-gray">
        <h1 className="text-2xl font-bold text-white">B•B STUDIOS</h1>
        <p className="text-sm text-gray-400 mt-1">Where boundaries break</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;

          return (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 px-4 py-3 h-auto ${
                  isActive 
                    ? "bg-bb-purple text-white" 
                    : "text-gray-400 hover:text-white hover:bg-bb-gray"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Button>
            </Link>
          );
        })}
      </nav>

      {/* Playlists */}
      <div className="p-4 border-t border-bb-gray">
        <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">
          Playlists
        </h3>
        <div className="space-y-2">
          {playlists.map((playlist) => (
            <Link key={playlist.id} href={`/playlist/${playlist.id}`}>
              <Button
                variant="ghost"
                className="w-full justify-start px-4 py-2 text-gray-400 hover:text-white h-auto"
              >
                {playlist.name}
              </Button>
            </Link>
          ))}
          {playlists.length === 0 && (
            <div className="space-y-2">
              <div className="px-4 py-2 text-gray-400">Dark Vibes</div>
              <div className="px-4 py-2 text-gray-400">Kink-Pop Essentials</div>
              <div className="px-4 py-2 text-gray-400">Trap Noir</div>
              <div className="px-4 py-2 text-gray-400">Seductive Rebellion</div>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}