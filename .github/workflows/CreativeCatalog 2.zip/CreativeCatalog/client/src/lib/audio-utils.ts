export function formatTime(seconds: number): string {
  if (!seconds || isNaN(seconds)) return "0:00";
  
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function parseTime(timeString: string): number {
  const parts = timeString.split(':');
  if (parts.length !== 2) return 0;
  
  const minutes = parseInt(parts[0], 10);
  const seconds = parseInt(parts[1], 10);
  
  if (isNaN(minutes) || isNaN(seconds)) return 0;
  
  return minutes * 60 + seconds;
}

export function generateWaveformData(duration: number, bars: number = 50): number[] {
  const data = [];
  for (let i = 0; i < bars; i++) {
    // Generate pseudo-random waveform data
    const progress = i / bars;
    const baseHeight = Math.sin(progress * Math.PI * 4) * 0.5 + 0.5;
    const noise = Math.random() * 0.3;
    data.push(Math.max(0.1, Math.min(1, baseHeight + noise)));
  }
  return data;
}

export function createAudioContext(): AudioContext | null {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    return new AudioContextClass();
  } catch (error) {
    console.warn('Web Audio API not supported:', error);
    return null;
  }
}

export function analyzeAudioFrequency(
  audioElement: HTMLAudioElement,
  canvas: HTMLCanvasElement
): void {
  const audioContext = createAudioContext();
  if (!audioContext) return;

  const source = audioContext.createMediaElementSource(audioElement);
  const analyzer = audioContext.createAnalyser();
  
  analyzer.fftSize = 256;
  source.connect(analyzer);
  analyzer.connect(audioContext.destination);

  const bufferLength = analyzer.frequencyBinCount;
  const dataArray = new Uint8Array(bufferLength);

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  function draw() {
    requestAnimationFrame(draw);
    
    analyzer.getByteFrequencyData(dataArray);
    
    ctx.fillStyle = 'rgb(10, 10, 10)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const barWidth = (canvas.width / bufferLength) * 2.5;
    let barHeight;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
      barHeight = (dataArray[i] / 255) * canvas.height;
      
      const gradient = ctx.createLinearGradient(0, canvas.height - barHeight, 0, canvas.height);
      gradient.addColorStop(0, '#8B5CF6');
      gradient.addColorStop(1, '#EC4899');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);

      x += barWidth + 1;
    }
  }

  draw();
}

export function loadAudioFile(url: string): Promise<HTMLAudioElement> {
  return new Promise((resolve, reject) => {
    const audio = new Audio();
    
    audio.addEventListener('canplaythrough', () => resolve(audio));
    audio.addEventListener('error', reject);
    
    audio.src = url;
    audio.load();
  });
}
