import { useState, useRef, useCallback } from "react";
import type { TrackWithArtist } from "@shared/schema";

interface AudioPlayerState {
  currentTrack: TrackWithArtist | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isLoading: boolean;
}

export function useAudioPlayer() {
  const [state, setState] = useState<AudioPlayerState>({
    currentTrack: null,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 70,
    isLoading: false,
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const play = useCallback((track?: TrackWithArtist) => {
    if (track) {
      setState(prev => ({
        ...prev,
        currentTrack: track,
        isLoading: true,
      }));
    }
    
    if (audioRef.current) {
      audioRef.current.play()
        .then(() => {
          setState(prev => ({
            ...prev,
            isPlaying: true,
            isLoading: false,
          }));
        })
        .catch(error => {
          console.error('Error playing audio:', error);
          setState(prev => ({
            ...prev,
            isLoading: false,
          }));
        });
    }
  }, []);

  const pause = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      setState(prev => ({
        ...prev,
        isPlaying: false,
      }));
    }
  }, []);

  const togglePlayPause = useCallback(() => {
    if (state.isPlaying) {
      pause();
    } else {
      play();
    }
  }, [state.isPlaying, play, pause]);

  const setCurrentTime = useCallback((time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setState(prev => ({
        ...prev,
        currentTime: time,
      }));
    }
  }, []);

  const setVolume = useCallback((volume: number) => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100;
      setState(prev => ({
        ...prev,
        volume,
      }));
    }
  }, []);

  return {
    ...state,
    audioRef,
    play,
    pause,
    togglePlayPause,
    setCurrentTime,
    setVolume,
  };
}
