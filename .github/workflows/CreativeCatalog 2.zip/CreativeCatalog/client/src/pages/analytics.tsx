import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BarChart, Shield, TrendingUp, Globe, DollarSign, Eye, Copyright, Award } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { TrackWithArtist, Artist, IpProtection, CrossPlatformAnalytics } from "@shared/schema";

export default function AnalyticsPage() {
  const [selectedArtist, setSelectedArtist] = useState<string>("all");
  const [timeframe, setTimeframe] = useState<string>("30d");

  const { data: tracks = [] } = useQuery<TrackWithArtist[]>({
    queryKey: ['/api/tracks'],
  });

  const { data: artists = [] } = useQuery<Artist[]>({
    queryKey: ['/api/artists'],
  });

  // Mock data for IP protection and cross-platform analytics
  const ipProtectionData: IpProtection[] = tracks.map((track, index) => ({
    id: index + 1,
    trackId: track.id,
    artistId: track.artistId,
    copyrightStatus: index % 3 === 0 ? 'registered' : index % 3 === 1 ? 'pending' : 'protected',
    registrationNumber: `CR-${2024}-${String(index + 1).padStart(6, '0')}`,
    registrationDate: new Date(),
    isrcCode: `USBB${2024}${String(index + 1).padStart(5, '0')}`,
    publishingRights: ['mechanical', 'performance', 'synchronization'],
    mechanicalRights: ['digital', 'physical'],
    syncRights: ['film', 'tv', 'advertising'],
    territorialRights: ['US', 'EU', 'global'],
    notes: `Copyright protection for ${track.title}`,
    createdAt: new Date()
  }));

  const crossPlatformData: CrossPlatformAnalytics[] = tracks.flatMap((track) => [
    {
      id: track.id * 10 + 1,
      trackId: track.id,
      artistId: track.artistId,
      platform: 'spotify',
      totalStreams: Math.floor(Math.random() * 100000) + 10000,
      monthlyStreams: Math.floor(Math.random() * 20000) + 2000,
      revenue: (Math.random() * 1000 + 100).toFixed(2),
      royalties: (Math.random() * 500 + 50).toFixed(2),
      territory: 'global',
      lastUpdated: new Date(),
      reportingPeriod: 'monthly'
    },
    {
      id: track.id * 10 + 2,
      trackId: track.id,
      artistId: track.artistId,
      platform: 'apple-music',
      totalStreams: Math.floor(Math.random() * 80000) + 5000,
      monthlyStreams: Math.floor(Math.random() * 15000) + 1000,
      revenue: (Math.random() * 800 + 80).toFixed(2),
      royalties: (Math.random() * 400 + 40).toFixed(2),
      territory: 'global',
      lastUpdated: new Date(),
      reportingPeriod: 'monthly'
    },
    {
      id: track.id * 10 + 3,
      trackId: track.id,
      artistId: track.artistId,
      platform: 'youtube',
      totalStreams: Math.floor(Math.random() * 200000) + 20000,
      monthlyStreams: Math.floor(Math.random() * 40000) + 5000,
      revenue: (Math.random() * 600 + 60).toFixed(2),
      royalties: (Math.random() * 300 + 30).toFixed(2),
      territory: 'global',
      lastUpdated: new Date(),
      reportingPeriod: 'monthly'
    }
  ]);

  const filteredTracks = selectedArtist === "all" 
    ? tracks 
    : tracks.filter(track => track.artistId.toString() === selectedArtist);

  const totalRevenue = crossPlatformData.reduce((sum, data) => sum + parseFloat(data.revenue?.toString() || '0'), 0);
  const totalStreams = crossPlatformData.reduce((sum, data) => sum + (data.totalStreams || 0), 0);
  const protectedTracks = ipProtectionData.filter(ip => ip.copyrightStatus === 'registered' || ip.copyrightStatus === 'protected').length;

  const getCopyrightStatusColor = (status: string) => {
    switch (status) {
      case 'registered': return 'bg-green-500';
      case 'protected': return 'bg-blue-500';
      case 'pending': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'spotify': return '🎵';
      case 'apple-music': return '🍎';
      case 'youtube': return '📺';
      case 'soundcloud': return '☁️';
      default: return '🎶';
    }
  };

  return (
    <div className="min-h-screen text-white" style={{ backgroundColor: 'var(--bb-black)' }}>
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Analytics & IP Protection</h1>
          <p className="text-gray-400">Track performance across platforms and manage intellectual property rights</p>
        </div>

        {/* Filters */}
        <div className="flex gap-4 mb-8">
          <Select value={selectedArtist} onValueChange={setSelectedArtist}>
            <SelectTrigger className="w-48 bg-bb-dark border-bb-gray">
              <SelectValue placeholder="Filter by artist" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Artists</SelectItem>
              {artists.map((artist) => (
                <SelectItem key={artist.id} value={artist.id.toString()}>
                  {artist.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-48 bg-bb-dark border-bb-gray">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-bb-dark">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="cross-platform">Cross-Platform</TabsTrigger>
            <TabsTrigger value="ip-protection">IP Protection</TabsTrigger>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-bb-dark border-bb-gray p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Total Streams</p>
                    <h3 className="text-2xl font-bold text-bb-purple">{totalStreams.toLocaleString()}</h3>
                  </div>
                  <TrendingUp className="w-8 h-8 text-bb-purple" />
                </div>
              </Card>
              
              <Card className="bg-bb-dark border-bb-gray p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Total Revenue</p>
                    <h3 className="text-2xl font-bold text-bb-green">${totalRevenue.toLocaleString()}</h3>
                  </div>
                  <DollarSign className="w-8 h-8 text-bb-green" />
                </div>
              </Card>
              
              <Card className="bg-bb-dark border-bb-gray p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Protected Tracks</p>
                    <h3 className="text-2xl font-bold text-bb-pink">{protectedTracks}</h3>
                  </div>
                  <Shield className="w-8 h-8 text-bb-pink" />
                </div>
              </Card>
              
              <Card className="bg-bb-dark border-bb-gray p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Active Platforms</p>
                    <h3 className="text-2xl font-bold text-white">3</h3>
                  </div>
                  <Globe className="w-8 h-8 text-white" />
                </div>
              </Card>
            </div>

            {/* Top Performing Tracks */}
            <Card className="bg-bb-dark border-bb-gray p-6">
              <h3 className="text-xl font-bold mb-4">Top Performing Tracks</h3>
              <div className="space-y-4">
                {filteredTracks.slice(0, 5).map((track) => {
                  const trackCrossPlatform = crossPlatformData.filter(cp => cp.trackId === track.id);
                  const trackStreams = trackCrossPlatform.reduce((sum, cp) => sum + (cp.totalStreams || 0), 0);
                  const trackRevenue = trackCrossPlatform.reduce((sum, cp) => sum + parseFloat(cp.revenue?.toString() || '0'), 0);
                  
                  return (
                    <div key={track.id} className="flex items-center justify-between p-4 bg-bb-gray rounded-lg">
                      <div>
                        <h4 className="font-semibold">{track.title}</h4>
                        <p className="text-gray-400 text-sm">{track.artist.name}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{trackStreams.toLocaleString()} streams</p>
                        <p className="text-bb-green text-sm">${trackRevenue.toFixed(2)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="cross-platform" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {['spotify', 'apple-music', 'youtube'].map((platform) => {
                const platformData = crossPlatformData.filter(cp => cp.platform === platform);
                const platformStreams = platformData.reduce((sum, cp) => sum + (cp.totalStreams || 0), 0);
                const platformRevenue = platformData.reduce((sum, cp) => sum + parseFloat(cp.revenue?.toString() || '0'), 0);
                
                return (
                  <Card key={platform} className="bg-bb-dark border-bb-gray p-6">
                    <div className="flex items-center mb-4">
                      <span className="text-2xl mr-3">{getPlatformIcon(platform)}</span>
                      <h3 className="text-xl font-bold capitalize">{platform.replace('-', ' ')}</h3>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Total Streams:</span>
                        <span className="font-semibold">{platformStreams.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Revenue:</span>
                        <span className="font-semibold text-bb-green">${platformRevenue.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Active Tracks:</span>
                        <span className="font-semibold">{platformData.length}</span>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="ip-protection" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {ipProtectionData.map((ip) => {
                const track = tracks.find(t => t.id === ip.trackId);
                if (!track) return null;
                
                return (
                  <Card key={ip.id} className="bg-bb-dark border-bb-gray p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">{track.title}</h3>
                      <Badge className={`${getCopyrightStatusColor(ip.copyrightStatus)} text-white`}>
                        {ip.copyrightStatus}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center">
                        <Copyright className="w-4 h-4 mr-2 text-bb-purple" />
                        <span>ISRC: {ip.isrcCode}</span>
                      </div>
                      
                      <div className="flex items-center">
                        <Award className="w-4 h-4 mr-2 text-bb-pink" />
                        <span>Reg: {ip.registrationNumber}</span>
                      </div>
                      
                      <div className="mt-3">
                        <p className="text-gray-400 text-xs mb-1">Rights Protected:</p>
                        <div className="flex flex-wrap gap-1">
                          {ip.publishingRights?.slice(0, 3).map((right) => (
                            <Badge key={right} variant="secondary" className="text-xs bg-bb-gray">
                              {right}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="revenue" className="space-y-6">
            <Card className="bg-bb-dark border-bb-gray p-6">
              <h3 className="text-xl font-bold mb-4">Revenue Breakdown by Platform</h3>
              <div className="space-y-4">
                {['spotify', 'apple-music', 'youtube'].map((platform) => {
                  const platformRevenue = crossPlatformData
                    .filter(cp => cp.platform === platform)
                    .reduce((sum, cp) => sum + parseFloat(cp.revenue?.toString() || '0'), 0);
                  const percentage = ((platformRevenue / totalRevenue) * 100).toFixed(1);
                  
                  return (
                    <div key={platform} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="capitalize flex items-center">
                          <span className="mr-2">{getPlatformIcon(platform)}</span>
                          {platform.replace('-', ' ')}
                        </span>
                        <span className="font-semibold">${platformRevenue.toFixed(2)} ({percentage}%)</span>
                      </div>
                      <div className="w-full bg-bb-gray rounded-full h-2">
                        <div 
                          className="h-2 rounded-full bg-gradient-to-r from-bb-purple to-bb-pink"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}