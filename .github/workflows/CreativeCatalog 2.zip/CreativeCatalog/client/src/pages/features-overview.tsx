
import React from 'react';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { 
  Music, 
  Mic, 
  Users, 
  BarChart3, 
  Shield, 
  Zap, 
  Globe, 
  DollarSign,
  Clock,
  Headphones,
  Radio,
  Award,
  Building,
  Sparkles,
  Target,
  TrendingUp,
  FileMusic,
  Settings,
  Database,
  Palette
} from 'lucide-react';

export default function FeaturesOverview() {
  const featureCategories = [
    {
      title: "Core Music Platform",
      color: "bb-purple",
      icon: <Music className="w-6 h-6" />,
      features: [
        {
          name: "Artist Management",
          description: "Complete artist profiles with bios, images, and social links",
          icon: <Users className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Track Library",
          description: "Metadata management (BPM, key, mood, genre, duration)",
          icon: <FileMusic className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Audio Player",
          description: "Custom player with waveform visualization",
          icon: <Headphones className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Playlist System",
          description: "Create and manage custom playlists",
          icon: <Radio className="w-5 h-5" />,
          status: "live"
        }
      ]
    },
    {
      title: "Professional Studio Services",
      color: "bb-pink",
      icon: <Mic className="w-6 h-6" />,
      features: [
        {
          name: "Studio Booking",
          description: "Professional facility with Neumann mics, Pro Tools HDX",
          icon: <Building className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Session Management",
          description: "Recording session scheduling and tracking",
          icon: <Clock className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Equipment Inventory",
          description: "SSL preamps, Universal Audio, vintage analog gear",
          icon: <Settings className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Engineering Services",
          description: "On-site mixing, mastering, and production support",
          icon: <Award className="w-5 h-5" />,
          status: "live"
        }
      ]
    },
    {
      title: "VIP AI Distribution",
      color: "bb-green",
      icon: <Zap className="w-6 h-6" />,
      features: [
        {
          name: "AI-Powered Distribution",
          description: "Automatic upload to Spotify, Apple Music, YouTube Music",
          icon: <Sparkles className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Metadata Optimization",
          description: "AI-generated titles, descriptions, and marketing materials",
          icon: <Target className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Multi-Platform Release",
          description: "Simultaneous distribution across major streaming platforms",
          icon: <Globe className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Label Management",
          description: "B•B Studios label with UPC/ISRC code generation",
          icon: <Database className="w-5 h-5" />,
          status: "live"
        }
      ]
    },
    {
      title: "Analytics & Revenue",
      color: "bb-purple",
      icon: <BarChart3 className="w-6 h-6" />,
      features: [
        {
          name: "Streaming Analytics",
          description: "Cross-platform performance tracking and insights",
          icon: <TrendingUp className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Revenue Management",
          description: "70/30 artist-label split with transparent reporting",
          icon: <DollarSign className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Licensing Sales",
          description: "Track commercial licensing revenue tracking",
          icon: <Award className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Collaboration Splits",
          description: "Multi-artist revenue sharing and contribution tracking",
          icon: <Users className="w-5 h-5" />,
          status: "live"
        }
      ]
    },
    {
      title: "Licensing Platform",
      color: "bb-pink",
      icon: <Shield className="w-6 h-6" />,
      features: [
        {
          name: "Commercial Licensing",
          description: "Standard, exclusive, and custom license tiers",
          icon: <Shield className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "IP Protection",
          description: "Copyright registration and publishing rights management",
          icon: <Database className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Territorial Rights",
          description: "Geographic licensing and distribution control",
          icon: <Globe className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Usage Tracking",
          description: "Monitor how licensed tracks are being used",
          icon: <BarChart3 className="w-5 h-5" />,
          status: "live"
        }
      ]
    },
    {
      title: "Technical Infrastructure",
      color: "bb-green",
      icon: <Settings className="w-6 h-6" />,
      features: [
        {
          name: "React + TypeScript",
          description: "Modern frontend with type safety and component architecture",
          icon: <Palette className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "Express.js Backend",
          description: "RESTful API with middleware and error handling",
          icon: <Database className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "PostgreSQL + Drizzle",
          description: "Type-safe database interactions with migrations",
          icon: <Database className="w-5 h-5" />,
          status: "live"
        },
        {
          name: "TanStack Query",
          description: "Advanced state management and caching",
          icon: <Settings className="w-5 h-5" />,
          status: "live"
        }
      ]
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'beta': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'development': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'bb-purple': return 'border-bb-purple text-bb-purple bg-bb-purple/10';
      case 'bb-pink': return 'border-bb-pink text-bb-pink bg-bb-pink/10';
      case 'bb-green': return 'border-bb-green text-bb-green bg-bb-green/10';
      default: return 'border-bb-gray text-bb-gray bg-bb-gray/10';
    }
  };

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-bb-purple via-bb-pink to-bb-green bg-clip-text text-transparent">
          B•B Studios Platform Overview
        </h1>
        <p className="text-xl text-gray-300 max-w-3xl mx-auto">
          Complete music production, distribution, and licensing ecosystem combining traditional studio services with AI-powered streaming distribution
        </p>
        <div className="flex justify-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-gray-400">Live Features</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <span className="text-gray-400">Beta</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
            <span className="text-gray-400">Development</span>
          </div>
        </div>
      </div>

      {/* Feature Categories */}
      <div className="space-y-8">
        {featureCategories.map((category, categoryIndex) => (
          <div key={categoryIndex} className="space-y-4">
            {/* Category Header */}
            <div className={`flex items-center gap-3 p-4 rounded-lg border ${getColorClasses(category.color)}`}>
              {category.icon}
              <h2 className="text-2xl font-bold">{category.title}</h2>
              <Badge className={`ml-auto ${getStatusColor('live')}`}>
                {category.features.length} Features
              </Badge>
            </div>

            {/* Feature Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {category.features.map((feature, featureIndex) => (
                <Card key={featureIndex} className="bg-bb-dark border-bb-gray p-4 hover:border-bb-gray-light transition-colors">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className={`p-2 rounded-lg ${getColorClasses(category.color)}`}>
                        {feature.icon}
                      </div>
                      <Badge className={getStatusColor(feature.status)}>
                        {feature.status}
                      </Badge>
                    </div>
                    <div>
                      <h3 className="font-semibold text-white mb-1">{feature.name}</h3>
                      <p className="text-sm text-gray-400 leading-relaxed">{feature.description}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Platform Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-12">
        <Card className="bg-bb-dark border-bb-purple p-6 text-center">
          <div className="text-3xl font-bold text-bb-purple mb-2">25+</div>
          <div className="text-gray-400">Total Features</div>
        </Card>
        <Card className="bg-bb-dark border-bb-pink p-6 text-center">
          <div className="text-3xl font-bold text-bb-pink mb-2">6</div>
          <div className="text-gray-400">Major Categories</div>
        </Card>
        <Card className="bg-bb-dark border-bb-green p-6 text-center">
          <div className="text-3xl font-bold text-bb-green mb-2">4+</div>
          <div className="text-gray-400">Streaming Platforms</div>
        </Card>
        <Card className="bg-bb-dark border-bb-gray p-6 text-center">
          <div className="text-3xl font-bold text-white mb-2">AI</div>
          <div className="text-gray-400">Powered Distribution</div>
        </Card>
      </div>

      {/* Technology Stack */}
      <Card className="bg-bb-dark border-bb-gray p-6">
        <h3 className="text-xl font-bold mb-4 text-bb-accent">Technology Stack</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-3 bg-bb-darker rounded-lg">
            <div className="text-bb-purple font-semibold">Frontend</div>
            <div className="text-sm text-gray-400 mt-1">React + TypeScript</div>
          </div>
          <div className="text-center p-3 bg-bb-darker rounded-lg">
            <div className="text-bb-pink font-semibold">Backend</div>
            <div className="text-sm text-gray-400 mt-1">Express.js + Node</div>
          </div>
          <div className="text-center p-3 bg-bb-darker rounded-lg">
            <div className="text-bb-green font-semibold">Database</div>
            <div className="text-sm text-gray-400 mt-1">PostgreSQL + Drizzle</div>
          </div>
          <div className="text-center p-3 bg-bb-darker rounded-lg">
            <div className="text-bb-accent font-semibold">Styling</div>
            <div className="text-sm text-gray-400 mt-1">Tailwind + Radix</div>
          </div>
        </div>
      </Card>
    </div>
  );
}
