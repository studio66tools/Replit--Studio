import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Calendar, Clock, Mic, Music, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertStudioSessionSchema, type Artist, type StudioSessionWithArtist } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function StudioPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: sessions = [], isLoading } = useQuery<StudioSessionWithArtist[]>({
    queryKey: ['/api/studio-sessions'],
  });

  const { data: artists = [] } = useQuery<Artist[]>({
    queryKey: ['/api/artists'],
  });

  const form = useForm({
    resolver: zodResolver(insertStudioSessionSchema),
    defaultValues: {
      artistId: undefined,
      sessionDate: new Date(),
      duration: 4,
      equipment: [],
      status: "scheduled",
      notes: "",
      cost: "150.00"
    }
  });

  const createSessionMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/studio-sessions', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/studio-sessions'] });
      toast({ title: "Studio session booked successfully!" });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ title: "Failed to book session", variant: "destructive" });
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-500';
      case 'in-progress': return 'bg-yellow-500';
      case 'completed': return 'bg-green-500';
      case 'cancelled': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const equipment = [
    "Neumann U87 Microphone", "Universal Audio Apollo Interface", "Yamaha HS8 Studio Monitors", 
    "Native Instruments Komplete Kontrol", "Marshall JCM800 Guitar Amp", "Pearl Reference Drum Kit", 
    "Moog Subsequent 37 Synthesizer", "SSL VHD Pre-amp", "Pro Tools HDX System"
  ];

  return (
    <div className="min-h-screen text-white" style={{ backgroundColor: 'var(--bb-black)' }}>
      <div className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">B•B Studios</h1>
            <p className="text-gray-400">Book recording sessions at our professional studio facility</p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="px-6 py-3"
                style={{ background: 'linear-gradient(to right, hsl(258, 90%, 66%), hsl(323, 83%, 62%))' }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Book Session
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-bb-dark border-bb-gray text-white">
              <DialogHeader>
                <DialogTitle>Book Studio Session</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit((data) => createSessionMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="artistId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Artist</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select artist" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {artists.map((artist) => (
                              <SelectItem key={artist.id} value={artist.id.toString()}>
                                {artist.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="duration"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Duration (hours)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} onChange={(e) => field.onChange(parseInt(e.target.value))} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Session Notes</FormLabel>
                        <FormControl>
                          <Textarea {...field} placeholder="What will you be recording?" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <Button type="submit" disabled={createSessionMutation.isPending} className="w-full">
                    {createSessionMutation.isPending ? "Booking..." : "Book Session"}
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Studio Info Banner */}
        <div className="bg-bb-dark rounded-lg p-6 mb-8 border border-bb-gray">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-xl font-bold mb-3 text-bb-purple">Studio Location</h3>
              <p className="text-gray-300 mb-2">Professional recording facility located in the heart of the music district</p>
              <p className="text-gray-400 text-sm">Full address provided upon booking confirmation</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-3 text-bb-pink">Studio Rates</h3>
              <div className="space-y-1 text-gray-300">
                <p>Recording Session: <span className="text-bb-green">$150/hour</span></p>
                <p>Half Day (4 hours): <span className="text-bb-green">$500</span></p>
                <p>Full Day (8 hours): <span className="text-bb-green">$900</span></p>
              </div>
            </div>
          </div>
        </div>

        {/* Studio Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-bb-dark border-bb-gray p-6">
            <div className="flex items-center mb-4">
              <Mic className="w-8 h-8 text-bb-purple mr-3" />
              <h3 className="text-xl font-bold">Professional Recording</h3>
            </div>
            <p className="text-gray-400">State-of-the-art recording booth with Neumann microphones and pristine acoustics</p>
          </Card>
          
          <Card className="bg-bb-dark border-bb-gray p-6">
            <div className="flex items-center mb-4">
              <Music className="w-8 h-8 text-bb-pink mr-3" />
              <h3 className="text-xl font-bold">Full Production Suite</h3>
            </div>
            <p className="text-gray-400">Pro Tools HD with vintage analog gear and modern digital workstations</p>
          </Card>
          
          <Card className="bg-bb-dark border-bb-gray p-6">
            <div className="flex items-center mb-4">
              <Clock className="w-8 h-8 text-bb-green mr-3" />
              <h3 className="text-xl font-bold">Flexible Scheduling</h3>
            </div>
            <p className="text-gray-400">Evening and weekend availability with on-site engineering support</p>
          </Card>
        </div>

        {/* Available Equipment */}
        <div className="bg-bb-dark rounded-lg p-6 mb-8 border border-bb-gray">
          <h3 className="text-xl font-bold mb-4">Studio Equipment & Services</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-bb-purple mb-3">Recording Equipment</h4>
              <ul className="space-y-1 text-sm text-gray-300">
                <li>• Neumann U87 & TLM 103 microphones</li>
                <li>• Universal Audio Apollo x8p interface</li>
                <li>• SSL VHD pre-amplifiers</li>
                <li>• Pro Tools HDX system</li>
                <li>• Yamaha HS8 & NS-10M monitors</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-bb-pink mb-3">Additional Services</h4>
              <ul className="space-y-1 text-sm text-gray-300">
                <li>• On-site recording engineer</li>
                <li>• Mixing & mastering services</li>
                <li>• Vintage analog gear rental</li>
                <li>• Multi-track recording up to 32 channels</li>
                <li>• High-resolution audio delivery</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Studio Sessions */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Upcoming Sessions</h2>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="bg-bb-dark border-bb-gray p-6 animate-pulse">
                  <div className="h-6 bg-bb-gray rounded mb-4" />
                  <div className="h-4 bg-bb-gray rounded mb-2" />
                  <div className="h-4 bg-bb-gray rounded w-2/3" />
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sessions.map((session) => (
                <Card key={session.id} className="bg-bb-dark border-bb-gray p-6 hover:bg-bb-gray transition-colors">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold">{session.artist.name}</h3>
                    <Badge className={`${getStatusColor(session.status || 'scheduled')} text-white`}>
                      {session.status}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 text-sm text-gray-400">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      {new Date(session.sessionDate).toLocaleDateString()}
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-2" />
                      {session.duration} hours
                    </div>
                    {session.cost && (
                      <div className="text-bb-purple font-semibold">
                        ${session.cost}
                      </div>
                    )}
                  </div>
                  
                  {session.notes && (
                    <p className="mt-4 text-sm text-gray-300">{session.notes}</p>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}