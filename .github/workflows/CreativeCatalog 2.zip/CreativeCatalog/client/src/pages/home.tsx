import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import AudioPlayer from "@/components/player/audio-player";
import ArtistCard from "@/components/music/artist-card";
import TrackItem from "@/components/music/track-item";
import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";
import type { Artist, TrackWithArtist } from "@shared/schema";

export default function Home() {
  const [currentTrack, setCurrentTrack] = useState<TrackWithArtist | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const { data: artists = [], isLoading: artistsLoading } = useQuery<Artist[]>({
    queryKey: ['/api/artists'],
  });

  const { data: tracks = [], isLoading: tracksLoading } = useQuery<TrackWithArtist[]>({
    queryKey: ['/api/tracks'],
  });

  const handlePlayTrack = (track: TrackWithArtist) => {
    setCurrentTrack(track);
    setIsPlaying(true);
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const genres = [
    { name: "Kink-Pop", description: "Provocative and bold", gradient: "linear-gradient(135deg, hsl(258, 90%, 66%), hsl(323, 83%, 62%))" },
    { name: "Trap Noir", description: "Dark urban vibes", gradient: "linear-gradient(135deg, hsl(220, 13%, 18%), hsl(0, 0%, 4%))" },
    { name: "Seductive", description: "Sultry and hypnotic", gradient: "linear-gradient(135deg, hsl(323, 83%, 62%), hsl(0, 84%, 60%))" },
    { name: "Electronic", description: "Cutting-edge beats", gradient: "linear-gradient(135deg, hsl(158, 76%, 39%), hsl(258, 90%, 66%))" },
  ];

  return (
    <div className="flex h-screen text-white" style={{ backgroundColor: 'var(--bb-black)' }}>
      <Sidebar />
      
      <main className="flex-1 flex flex-col">
        <TopBar />
        
        <div className="flex-1 overflow-y-auto pb-24">
          {/* Hero Section */}
          <section className="relative p-8">
            <div 
              className="absolute inset-0 bg-cover bg-center"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=600')"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-bb-black via-bb-black/80 to-transparent" />
            
            <div className="relative z-10 max-w-2xl">
              <h2 className="text-6xl font-black mb-4 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                UNLEASH THE DARKNESS
              </h2>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                A bold new label crafting sounds that burn, bite, and breathe originality. 
                Here, we don't follow trends — we provoke them.
              </p>
              <Button 
                className="px-8 py-4 text-lg font-bold hover:shadow-lg transition-all"
                style={{ 
                  background: 'linear-gradient(to right, hsl(258, 90%, 66%), hsl(323, 83%, 62%))',
                  boxShadow: '0 4px 14px 0 rgba(139, 92, 246, 0.5)'
                }}
                onClick={() => tracks.length > 0 && handlePlayTrack(tracks[0])}
              >
                <Play className="w-5 h-5 mr-2" />
                Start Listening
              </Button>
            </div>
          </section>

          {/* Featured Artists */}
          <section className="px-8 py-8">
            <h3 className="text-3xl font-bold mb-6">Our Artists</h3>
            {artistsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="bg-bb-dark rounded-xl p-6 animate-pulse">
                    <div className="w-full h-48 bg-bb-gray rounded-lg mb-4" />
                    <div className="h-6 bg-bb-gray rounded mb-2" />
                    <div className="h-4 bg-bb-gray rounded" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {artists.map((artist) => (
                  <ArtistCard 
                    key={artist.id} 
                    artist={artist}
                    onPlay={() => {
                      const artistTracks = tracks.filter(t => t.artistId === artist.id);
                      if (artistTracks.length > 0) {
                        handlePlayTrack(artistTracks[0]);
                      }
                    }}
                  />
                ))}
              </div>
            )}
          </section>

          {/* Recently Played */}
          <section className="px-8 py-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-3xl font-bold">Recently Played</h3>
              <Button variant="ghost" className="text-gray-400 hover:text-white">
                Show all
              </Button>
            </div>
            
            {tracksLoading ? (
              <div className="space-y-2">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="p-4 rounded-lg animate-pulse">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-bb-gray rounded-full" />
                      <div className="w-16 h-8 bg-bb-gray rounded" />
                      <div className="flex-1">
                        <div className="h-4 bg-bb-gray rounded mb-2" />
                        <div className="h-3 bg-bb-gray rounded w-1/2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                {tracks.slice(0, 5).map((track) => (
                  <TrackItem
                    key={track.id}
                    track={track}
                    isCurrentTrack={currentTrack?.id === track.id}
                    isPlaying={isPlaying && currentTrack?.id === track.id}
                    onPlay={() => handlePlayTrack(track)}
                  />
                ))}
              </div>
            )}
          </section>

          {/* Genre Categories */}
          <section className="px-8 py-8">
            <h3 className="text-3xl font-bold mb-6">Browse by Genre</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {genres.map((genre) => (
                <div 
                  key={genre.name}
                  className="relative p-6 rounded-xl cursor-pointer hover:scale-105 transition-transform"
                  style={{ background: genre.gradient }}
                >
                  <h4 className="text-xl font-bold mb-2">{genre.name}</h4>
                  <p className="text-sm opacity-80">{genre.description}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
        
        <AudioPlayer 
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          onPlayPause={handlePlayPause}
          onNext={() => {
            if (currentTrack) {
              const currentIndex = tracks.findIndex(t => t.id === currentTrack.id);
              const nextTrack = tracks[currentIndex + 1];
              if (nextTrack) {
                handlePlayTrack(nextTrack);
              }
            }
          }}
          onPrevious={() => {
            if (currentTrack) {
              const currentIndex = tracks.findIndex(t => t.id === currentTrack.id);
              const prevTrack = tracks[currentIndex - 1];
              if (prevTrack) {
                handlePlayTrack(prevTrack);
              }
            }
          }}
        />
      </main>
    </div>
  );
}
