import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Upload, Music, Zap, CheckCircle, Clock, AlertCircle, ExternalLink } from "lucide-react";
import type { Track, Artist } from "@shared/schema";

interface DistributionResult {
  success: boolean;
  distribution: any;
  platformResults: Array<{
    platform: string;
    status: 'success' | 'failed' | 'pending';
    distributionId?: string;
    message: string;
  }>;
  aiMetadata: {
    optimizedTitle: string;
    description: string;
    tags: string[];
    genre: string;
    mood: string;
    spotifyDescription: string;
    appleMusicDescription: string;
    youtubeDescription: string;
    releaseStrategy: {
      optimalReleaseDate: string;
      marketingKeywords: string[];
      targetAudience: string;
    };
  };
  message: string;
}

export default function VipDistribution() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTrack, setSelectedTrack] = useState<number | null>(null);
  const [selectedArtist, setSelectedArtist] = useState<number | null>(null);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(['spotify', 'apple-music', 'youtube-music']);
  const [distributionResult, setDistributionResult] = useState<DistributionResult | null>(null);

  // Fetch data
  const { data: tracks = [] } = useQuery<Track[]>({
    queryKey: ['/api/tracks'],
  });

  const { data: artists = [] } = useQuery<Artist[]>({
    queryKey: ['/api/artists'],
  });

  const { data: distributions = [] } = useQuery({
    queryKey: ['/api/distributions'],
  });

  const { data: vipServices = [] } = useQuery({
    queryKey: ['/api/vip/services'],
  });

  // Distribution mutation
  const distributeMutation = useMutation({
    mutationFn: async (data: { trackId: number; artistId: number; platforms: string[] }) => {
      return apiRequest('/api/vip/distribute', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' }
      });
    },
    onSuccess: (data: DistributionResult) => {
      setDistributionResult(data);
      queryClient.invalidateQueries({ queryKey: ['/api/distributions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/vip/services'] });
      toast({
        title: "Distribution Complete!",
        description: data.message,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Distribution Failed",
        description: error.message || "Failed to distribute track",
        variant: "destructive",
      });
    },
  });

  const handleDistribute = () => {
    if (!selectedTrack || !selectedArtist) {
      toast({
        title: "Missing Information",
        description: "Please select both a track and artist",
        variant: "destructive",
      });
      return;
    }

    distributeMutation.mutate({
      trackId: selectedTrack,
      artistId: selectedArtist,
      platforms: selectedPlatforms,
    });
  };

  const togglePlatform = (platform: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platform) 
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  const selectedTrackData = tracks.find(t => t.id === selectedTrack);
  const selectedArtistData = artists.find(a => a.id === selectedArtist);

  const platformIcons: Record<string, string> = {
    'spotify': '🎵',
    'apple-music': '🍎',
    'youtube-music': '🎥',
    'amazon-music': '📦',
  };

  const platformNames: Record<string, string> = {
    'spotify': 'Spotify',
    'apple-music': 'Apple Music',
    'youtube-music': 'YouTube Music',
    'amazon-music': 'Amazon Music',
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Zap className="h-8 w-8 text-bb-accent" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-bb-accent to-bb-pink bg-clip-text text-transparent">
            VIP Distribution
          </h1>
        </div>
        <p className="text-bb-gray text-lg max-w-2xl mx-auto">
          Upload your tracks to B•B Studios and automatically distribute to major streaming platforms 
          using AI-powered optimization. Exclusive service for artists recording at our studio.
        </p>
      </div>

      <Tabs defaultValue="distribute" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="distribute">New Distribution</TabsTrigger>
          <TabsTrigger value="status">Distribution Status</TabsTrigger>
          <TabsTrigger value="services">VIP Services</TabsTrigger>
        </TabsList>

        {/* New Distribution Tab */}
        <TabsContent value="distribute" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Upload Form */}
            <Card className="bg-bb-dark border-bb-gray p-6">
              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <Upload className="h-6 w-6 text-bb-accent" />
                  <h3 className="text-xl font-semibold">Select Track & Artist</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label className="text-bb-gray mb-2 block">Select Track</Label>
                    <Select value={selectedTrack?.toString() || ""} onValueChange={(value) => setSelectedTrack(parseInt(value))}>
                      <SelectTrigger className="bg-bb-darker border-bb-gray">
                        <SelectValue placeholder="Choose a track to distribute" />
                      </SelectTrigger>
                      <SelectContent>
                        {tracks.map((track) => (
                          <SelectItem key={track.id} value={track.id.toString()}>
                            {track.title} - {artists.find(a => a.id === track.artistId)?.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-bb-gray mb-2 block">Select Artist</Label>
                    <Select value={selectedArtist?.toString() || ""} onValueChange={(value) => setSelectedArtist(parseInt(value))}>
                      <SelectTrigger className="bg-bb-darker border-bb-gray">
                        <SelectValue placeholder="Choose the artist" />
                      </SelectTrigger>
                      <SelectContent>
                        {artists.map((artist) => (
                          <SelectItem key={artist.id} value={artist.id.toString()}>
                            {artist.emoji} {artist.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-bb-gray mb-3 block">Distribution Platforms</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {['spotify', 'apple-music', 'youtube-music', 'amazon-music'].map((platform) => (
                        <div
                          key={platform}
                          className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                            selectedPlatforms.includes(platform)
                              ? 'border-bb-accent bg-bb-accent/10'
                              : 'border-bb-gray bg-bb-darker hover:border-bb-gray-light'
                          }`}
                          onClick={() => togglePlatform(platform)}
                        >
                          <div className="text-xl">{platformIcons[platform]}</div>
                          <span className="text-sm font-medium">{platformNames[platform]}</span>
                          <div className="ml-auto">
                            <div className={`w-4 h-4 rounded border-2 ${
                              selectedPlatforms.includes(platform) 
                                ? 'bg-bb-accent border-bb-accent' 
                                : 'border-bb-gray'
                            }`} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    onClick={handleDistribute}
                    disabled={!selectedTrack || !selectedArtist || distributeMutation.isPending}
                    className="w-full bg-gradient-to-r from-bb-accent to-bb-pink text-white hover:opacity-90"
                    size="lg"
                  >
                    {distributeMutation.isPending ? (
                      <>
                        <Clock className="w-4 h-4 mr-2 animate-spin" />
                        Processing AI Distribution...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Start VIP Distribution
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </Card>

            {/* Preview/Result */}
            <Card className="bg-bb-dark border-bb-gray p-6">
              {distributionResult ? (
                <div className="space-y-6">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                    <h3 className="text-xl font-semibold text-green-500">Distribution Complete!</h3>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-bb-darker rounded-lg">
                      <h4 className="font-semibold text-bb-accent mb-2">AI-Optimized Metadata</h4>
                      <div className="space-y-2 text-sm">
                        <p><span className="text-bb-gray">Optimized Title:</span> {distributionResult.aiMetadata.optimizedTitle}</p>
                        <p><span className="text-bb-gray">Genre:</span> {distributionResult.aiMetadata.genre}</p>
                        <p><span className="text-bb-gray">Target Audience:</span> {distributionResult.aiMetadata.releaseStrategy.targetAudience}</p>
                        <div>
                          <span className="text-bb-gray">Tags:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {distributionResult.aiMetadata.tags.slice(0, 5).map((tag, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold">Platform Results</h4>
                      {distributionResult.platformResults.map((result, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-bb-darker rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="text-lg">{platformIcons[result.platform]}</div>
                            <span className="font-medium">{platformNames[result.platform]}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            {result.status === 'success' && <CheckCircle className="w-4 h-4 text-green-500" />}
                            {result.status === 'failed' && <AlertCircle className="w-4 h-4 text-red-500" />}
                            {result.status === 'pending' && <Clock className="w-4 h-4 text-yellow-500" />}
                            <span className={`text-sm ${
                              result.status === 'success' ? 'text-green-500' : 
                              result.status === 'failed' ? 'text-red-500' : 'text-yellow-500'
                            }`}>
                              {result.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="p-4 bg-gradient-to-r from-bb-accent/20 to-bb-pink/20 rounded-lg border border-bb-accent/30">
                      <p className="text-sm text-bb-accent font-medium">
                        ✨ Your track will be live on streaming platforms within 24-48 hours
                      </p>
                    </div>
                  </div>
                </div>
              ) : selectedTrackData && selectedArtistData ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Music className="h-6 w-6 text-bb-accent" />
                    <h3 className="text-xl font-semibold">Preview</h3>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold">{selectedTrackData.title}</h4>
                      <p className="text-bb-gray">by {selectedArtistData.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-bb-gray">Genre: {selectedTrackData.genre}</p>
                      <p className="text-sm text-bb-gray">Duration: {Math.floor((selectedTrackData.duration || 0) / 60)}:{((selectedTrackData.duration || 0) % 60).toString().padStart(2, '0')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-bb-gray mb-2">Selected Platforms:</p>
                      <div className="flex gap-2">
                        {selectedPlatforms.map(platform => (
                          <Badge key={platform} className="bg-bb-accent/20 text-bb-accent">
                            {platformIcons[platform]} {platformNames[platform]}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-64 text-bb-gray">
                  <Music className="h-16 w-16 mb-4 opacity-50" />
                  <p>Select a track and artist to see preview</p>
                </div>
              )}
            </Card>
          </div>
        </TabsContent>

        {/* Distribution Status Tab */}
        <TabsContent value="status" className="space-y-6">
          <Card className="bg-bb-dark border-bb-gray p-6">
            <h3 className="text-xl font-semibold mb-4">Recent Distributions</h3>
            {distributions.length > 0 ? (
              <div className="space-y-4">
                {distributions.slice(0, 10).map((dist: any, index: number) => {
                  const track = tracks.find(t => t.id === dist.trackId);
                  const artist = artists.find(a => a.id === dist.artistId);
                  return (
                    <div key={index} className="p-4 bg-bb-darker rounded-lg">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold">{track?.title || 'Unknown Track'}</h4>
                          <p className="text-bb-gray text-sm">by {artist?.name || 'Unknown Artist'}</p>
                          <p className="text-xs text-bb-gray mt-1">
                            Distributed: {new Date(dist.distributionDate).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge className={
                            dist.distributionStatus === 'distributed' ? 'bg-green-500/20 text-green-500' :
                            dist.distributionStatus === 'failed' ? 'bg-red-500/20 text-red-500' :
                            'bg-yellow-500/20 text-yellow-500'
                          }>
                            {dist.distributionStatus}
                          </Badge>
                          <div className="flex gap-1 mt-2">
                            {(dist.platforms || []).map((platform: string, i: number) => (
                              <div key={i} className="text-sm" title={platformNames[platform]}>
                                {platformIcons[platform]}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center text-bb-gray py-8">
                <Music className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p>No distributions yet</p>
              </div>
            )}
          </Card>
        </TabsContent>

        {/* VIP Services Tab */}
        <TabsContent value="services" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-gradient-to-br from-bb-accent/20 to-bb-pink/20 border-bb-accent p-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Zap className="h-8 w-8 text-bb-accent" />
                  <h3 className="text-xl font-bold">AI Distribution</h3>
                </div>
                <p className="text-sm text-bb-gray">
                  Automatic distribution to major streaming platforms with AI-optimized metadata
                </p>
                <ul className="text-sm space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Spotify, Apple Music, YouTube Music
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    AI-optimized titles & descriptions
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Revenue sharing: 70% artist, 30% label
                  </li>
                </ul>
                <div className="pt-4 border-t border-bb-gray/30">
                  <p className="text-2xl font-bold text-bb-accent">$199</p>
                  <p className="text-xs text-bb-gray">Per track distribution</p>
                </div>
              </div>
            </Card>

            <Card className="bg-bb-dark border-bb-gray p-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Music className="h-8 w-8 text-bb-pink" />
                  <h3 className="text-xl font-bold">Studio + Distribution</h3>
                </div>
                <p className="text-sm text-bb-gray">
                  Record at our studio and get automatic distribution included
                </p>
                <ul className="text-sm space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Professional recording session
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Mixing & mastering included
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Free AI distribution
                  </li>
                </ul>
                <div className="pt-4 border-t border-bb-gray/30">
                  <p className="text-2xl font-bold text-bb-pink">$899</p>
                  <p className="text-xs text-bb-gray">Full production package</p>
                </div>
              </div>
            </Card>

            <Card className="bg-bb-dark border-bb-gray p-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <ExternalLink className="h-8 w-8 text-bb-green" />
                  <h3 className="text-xl font-bold">Label Signing</h3>
                </div>
                <p className="text-sm text-bb-gray">
                  Join B•B Studios as a signed artist with ongoing support
                </p>
                <ul className="text-sm space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Unlimited studio access
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Free distribution & promotion
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Marketing support
                  </li>
                </ul>
                <div className="pt-4 border-t border-bb-gray/30">
                  <p className="text-2xl font-bold text-bb-green">Contact</p>
                  <p className="text-xs text-bb-gray">For partnership details</p>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}