import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download, DollarSign, Music, Tag, Clock, Key } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { TrackWithArtist } from "@shared/schema";

export default function LicensingPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [moodFilter, setMoodFilter] = useState("");
  const [genreFilter, setGenreFilter] = useState("");

  const { data: tracks = [], isLoading } = useQuery<TrackWithArtist[]>({
    queryKey: ['/api/tracks'],
  });

  const filteredTracks = tracks.filter(track => {
    const matchesSearch = track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         track.artist.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesMood = !moodFilter || moodFilter === "all-moods" || track.mood === moodFilter;
    const matchesGenre = !genreFilter || genreFilter === "all-genres" || track.genre === genreFilter;
    return matchesSearch && matchesMood && matchesGenre;
  });

  const moods = Array.from(new Set(tracks.map(t => t.mood).filter(Boolean).filter(mood => mood && mood.trim() !== '')));
  const genres = Array.from(new Set(tracks.map(t => t.genre).filter(Boolean).filter(genre => genre && genre.trim() !== '')));

  const getLicenseTypeColor = (type: string) => {
    switch (type) {
      case 'standard': return 'bg-blue-500';
      case 'exclusive': return 'bg-purple-500';
      case 'custom': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const formatPrice = (price: string | number | null) => {
    if (!price) return 'Contact for pricing';
    return `$${parseFloat(price.toString()).toFixed(2)}`;
  };

  return (
    <div className="min-h-screen text-white" style={{ backgroundColor: 'var(--bb-black)' }}>
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Music Licensing</h1>
          <p className="text-gray-400">License premium tracks from B•B Studios for your projects</p>
        </div>

        {/* License Types */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-bb-dark border-bb-gray p-6">
            <div className="flex items-center mb-4">
              <Music className="w-8 h-8 text-blue-500 mr-3" />
              <h3 className="text-xl font-bold">Standard License</h3>
            </div>
            <p className="text-gray-400 mb-4">Perfect for content creation, podcasts, and small commercial projects</p>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Commercial use allowed</li>
              <li>• Up to 10K views/listeners</li>
              <li>• High-quality audio files</li>
              <li>• Attribution required</li>
            </ul>
          </Card>
          
          <Card className="bg-bb-dark border-bb-gray p-6">
            <div className="flex items-center mb-4">
              <DollarSign className="w-8 h-8 text-purple-500 mr-3" />
              <h3 className="text-xl font-bold">Exclusive License</h3>
            </div>
            <p className="text-gray-400 mb-4">Full rights for major commercial projects and broadcasts</p>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Exclusive commercial rights</li>
              <li>• Unlimited usage</li>
              <li>• Stem files included</li>
              <li>• No attribution required</li>
            </ul>
          </Card>
          
          <Card className="bg-bb-dark border-bb-gray p-6">
            <div className="flex items-center mb-4">
              <Tag className="w-8 h-8 text-orange-500 mr-3" />
              <h3 className="text-xl font-bold">Custom License</h3>
            </div>
            <p className="text-gray-400 mb-4">Tailored licensing for specific needs and unique projects</p>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Custom terms</li>
              <li>• Negotiable pricing</li>
              <li>• Sync rights available</li>
              <li>• Direct artist collaboration</li>
            </ul>
          </Card>
        </div>

        {/* Filters */}
        <div className="bg-bb-dark rounded-lg p-6 mb-8">
          <h3 className="text-lg font-semibold mb-4">Find Your Perfect Track</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Input
              placeholder="Search tracks or artists..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-bb-gray border-bb-gray"
            />
            <Select value={moodFilter} onValueChange={setMoodFilter}>
              <SelectTrigger className="bg-bb-gray border-bb-gray">
                <SelectValue placeholder="Filter by mood" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-moods">All moods</SelectItem>
                {moods.map((mood) => (
                  <SelectItem key={mood} value={mood}>{mood}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={genreFilter} onValueChange={setGenreFilter}>
              <SelectTrigger className="bg-bb-gray border-bb-gray">
                <SelectValue placeholder="Filter by genre" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-genres">All genres</SelectItem>
                {genres.map((genre) => (
                  <SelectItem key={genre} value={genre}>{genre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              onClick={() => {
                setSearchQuery("");
                setMoodFilter("all-moods");
                setGenreFilter("all-genres");
              }}
              variant="outline"
              className="border-bb-gray"
            >
              Clear Filters
            </Button>
          </div>
        </div>

        {/* Track Grid */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Available Tracks ({filteredTracks.length})</h2>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(9)].map((_, i) => (
                <Card key={i} className="bg-bb-dark border-bb-gray p-6 animate-pulse">
                  <div className="h-6 bg-bb-gray rounded mb-4" />
                  <div className="h-4 bg-bb-gray rounded mb-2" />
                  <div className="h-4 bg-bb-gray rounded w-2/3 mb-4" />
                  <div className="h-10 bg-bb-gray rounded" />
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTracks.map((track) => (
                <Card key={track.id} className="bg-bb-dark border-bb-gray p-6 hover:bg-bb-gray transition-colors">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-1">{track.title}</h3>
                      <p className="text-gray-400 text-sm">{track.artist.name}</p>
                    </div>
                    <Badge className={`${getLicenseTypeColor(track.licenseType || 'standard')} text-white ml-2`}>
                      {track.licenseType}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 text-sm text-gray-400 mb-4">
                    {track.genre && (
                      <div className="flex items-center">
                        <Music className="w-4 h-4 mr-2" />
                        {track.genre}
                      </div>
                    )}
                    {track.bpm && (
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2" />
                        {track.bpm} BPM
                      </div>
                    )}
                    {track.key && (
                      <div className="flex items-center">
                        <Key className="w-4 h-4 mr-2" />
                        Key of {track.key}
                      </div>
                    )}
                  </div>

                  {track.tags && track.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-4">
                      {track.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs bg-bb-gray text-gray-300">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div className="text-lg font-bold text-bb-purple">
                      {formatPrice(track.licensePrice)}
                    </div>
                    <div className="space-x-2">
                      {track.downloadEnabled && (
                        <Button size="sm" variant="outline" className="border-bb-gray">
                          <Download className="w-4 h-4" />
                        </Button>
                      )}
                      <Button 
                        size="sm"
                        style={{ background: 'linear-gradient(to right, hsl(258, 90%, 66%), hsl(323, 83%, 62%))' }}
                      >
                        License Now
                      </Button>
                    </div>
                  </div>

                  {track.playCount && (
                    <div className="mt-2 text-xs text-gray-500">
                      {track.playCount.toLocaleString()} plays
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}