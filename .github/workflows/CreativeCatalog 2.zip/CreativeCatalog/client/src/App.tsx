import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import StudioPage from "@/pages/studio";
import LicensingPage from "@/pages/licensing";
import AnalyticsPage from "@/pages/analytics";
import VipDistributionPage from "@/pages/vip-distribution";
import FeaturesOverview from "@/pages/features-overview";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/studio" component={StudioPage} />
      <Route path="/licensing" component={LicensingPage} />
      <Route path="/analytics" component={AnalyticsPage} />
      <Route path="/vip-distribution" component={VipDistributionPage} />
      <Route path="/features" component={FeaturesOverview} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="dark min-h-screen text-white" style={{ backgroundColor: 'var(--bb-black)' }}>
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;