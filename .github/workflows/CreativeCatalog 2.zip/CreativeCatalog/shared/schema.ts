import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const artists = pgTable("artists", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  bio: text("bio"),
  imageUrl: text("image_url"),
  emoji: text("emoji"),
});

export const albums = pgTable("albums", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  artistId: integer("artist_id").notNull(),
  coverUrl: text("cover_url"),
  releaseYear: integer("release_year"),
});

export const tracks = pgTable("tracks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  artistId: integer("artist_id").notNull(),
  albumId: integer("album_id"),
  duration: integer("duration"), // in seconds
  audioUrl: text("audio_url"),
  genre: text("genre"),
  isLiked: boolean("is_liked").default(false),
  tags: text("tags").array(), // mood tags, style tags
  mood: text("mood"), // happy, dark, energetic, etc
  bpm: integer("bpm"),
  key: text("key"), // musical key
  licenseType: text("license_type").default("standard"), // standard, exclusive, custom
  licensePrice: decimal("license_price", { precision: 10, scale: 2 }),
  downloadEnabled: boolean("download_enabled").default(false),
  stemFilesUrl: text("stem_files_url"), // for separated audio stems
  playCount: integer("play_count").default(0),
  downloadCount: integer("download_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const playlists = pgTable("playlists", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
});

export const playlistTracks = pgTable("playlist_tracks", {
  id: serial("id").primaryKey(),
  playlistId: integer("playlist_id").notNull(),
  trackId: integer("track_id").notNull(),
  position: integer("position").notNull(),
});

// Studio booking and collaboration
export const studioSessions = pgTable("studio_sessions", {
  id: serial("id").primaryKey(),
  artistId: integer("artist_id").notNull(),
  sessionDate: timestamp("session_date").notNull(),
  duration: integer("duration"), // in hours
  equipment: text("equipment").array(), // list of equipment used
  status: text("status").default("scheduled"), // scheduled, in-progress, completed, cancelled
  notes: text("notes"),
  cost: decimal("cost", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Licensing and downloads
export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull(),
  buyerEmail: text("buyer_email").notNull(),
  licenseType: text("license_type").notNull(), // standard, exclusive, custom
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  purchaseDate: timestamp("purchase_date").defaultNow(),
  licenseTerms: text("license_terms"),
  downloadUrl: text("download_url"),
  expiryDate: timestamp("expiry_date"),
});

// Artist collaborations
export const collaborations = pgTable("collaborations", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull(),
  artistId: integer("artist_id").notNull(),
  role: text("role").notNull(), // producer, vocalist, mixer, etc
  contribution: text("contribution"), // description of their work
  revenue_share: decimal("revenue_share", { precision: 5, scale: 2 }), // percentage
  createdAt: timestamp("created_at").defaultNow(),
});

// Analytics and streaming stats
export const streamingStats = pgTable("streaming_stats", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull(),
  date: timestamp("date").defaultNow(),
  plays: integer("plays").default(0),
  uniqueListeners: integer("unique_listeners").default(0),
  downloads: integer("downloads").default(0),
  revenue: decimal("revenue", { precision: 10, scale: 2 }).default("0"),
  country: text("country"),
  platform: text("platform"), // web, mobile, etc
});

// IP Protection and Copyright Management
export const ipProtection = pgTable("ip_protection", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull(),
  artistId: integer("artist_id").notNull(),
  copyrightStatus: text("copyright_status").notNull(), // 'registered', 'pending', 'protected'
  registrationNumber: text("registration_number"),
  registrationDate: timestamp("registration_date"),
  isrcCode: text("isrc_code"), // International Standard Recording Code
  publishingRights: text("publishing_rights").array(),
  mechanicalRights: text("mechanical_rights").array(),
  syncRights: text("sync_rights").array(),
  territorialRights: text("territorial_rights").array(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Cross-Platform Analytics
export const crossPlatformAnalytics = pgTable("cross_platform_analytics", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull(),
  artistId: integer("artist_id").notNull(),
  platform: text("platform").notNull(), // 'spotify', 'apple-music', 'youtube', 'soundcloud', etc.
  totalStreams: integer("total_streams").default(0),
  monthlyStreams: integer("monthly_streams").default(0),
  revenue: decimal("revenue", { precision: 10, scale: 2 }).default("0.00"),
  royalties: decimal("royalties", { precision: 10, scale: 2 }).default("0.00"),
  territory: text("territory").default("global"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  reportingPeriod: text("reporting_period"), // 'daily', 'weekly', 'monthly'
});

// AI Distribution System for VIP Label Services
export const distribution = pgTable("distribution", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull(),
  artistId: integer("artist_id").notNull(),
  distributionStatus: text("distribution_status").notNull(), // 'pending', 'processing', 'distributed', 'failed'
  platforms: text("platforms").array().notNull(), // ['spotify', 'apple-music', 'youtube-music', 'amazon-music']
  aiGeneratedMetadata: jsonb("ai_generated_metadata"), // AI-optimized titles, descriptions, tags
  distributionDate: timestamp("distribution_date"),
  releaseDate: timestamp("release_date"),
  labelName: text("label_name").default("B•B Studios"),
  upc: text("upc"), // Universal Product Code
  catalogNumber: text("catalog_number"),
  distributionFee: decimal("distribution_fee", { precision: 8, scale: 2 }),
  revenueShare: decimal("revenue_share", { precision: 5, scale: 2 }), // Percentage split with artist
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// VIP Studio Services for Label Artists
export const vipServices = pgTable("vip_services", {
  id: serial("id").primaryKey(),
  artistId: integer("artist_id").notNull(),
  serviceType: text("service_type").notNull(), // 'recording', 'mixing', 'mastering', 'distribution', 'full-package'
  sessionId: integer("session_id"),
  trackId: integer("track_id"),
  status: text("status").notNull(), // 'scheduled', 'in-progress', 'completed', 'distributed'
  serviceDate: timestamp("service_date"),
  completionDate: timestamp("completion_date"),
  aiDistributionEnabled: boolean("ai_distribution_enabled").default(true),
  labelSigningStatus: text("label_signing_status"), // 'signed', 'pending', 'trial'
  packagePrice: decimal("package_price", { precision: 10, scale: 2 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertArtistSchema = createInsertSchema(artists).omit({ id: true });
export const insertAlbumSchema = createInsertSchema(albums).omit({ id: true });
export const insertTrackSchema = createInsertSchema(tracks).omit({ id: true, playCount: true, downloadCount: true, createdAt: true });
export const insertPlaylistSchema = createInsertSchema(playlists).omit({ id: true });
export const insertPlaylistTrackSchema = createInsertSchema(playlistTracks).omit({ id: true });
export const insertStudioSessionSchema = createInsertSchema(studioSessions).omit({ id: true, createdAt: true });
export const insertLicenseSchema = createInsertSchema(licenses).omit({ id: true, purchaseDate: true });
export const insertCollaborationSchema = createInsertSchema(collaborations).omit({ id: true, createdAt: true });
export const insertStreamingStatsSchema = createInsertSchema(streamingStats).omit({ id: true, date: true });
export const insertIpProtectionSchema = createInsertSchema(ipProtection).omit({ id: true, createdAt: true });
export const insertCrossPlatformAnalyticsSchema = createInsertSchema(crossPlatformAnalytics).omit({ id: true, lastUpdated: true });
export const insertDistributionSchema = createInsertSchema(distribution).omit({ id: true, createdAt: true });
export const insertVipServicesSchema = createInsertSchema(vipServices).omit({ id: true, createdAt: true });

export type Artist = typeof artists.$inferSelect;
export type Album = typeof albums.$inferSelect;
export type Track = typeof tracks.$inferSelect;
export type Playlist = typeof playlists.$inferSelect;
export type PlaylistTrack = typeof playlistTracks.$inferSelect;
export type StudioSession = typeof studioSessions.$inferSelect;
export type License = typeof licenses.$inferSelect;
export type Collaboration = typeof collaborations.$inferSelect;
export type StreamingStats = typeof streamingStats.$inferSelect;
export type IpProtection = typeof ipProtection.$inferSelect;
export type CrossPlatformAnalytics = typeof crossPlatformAnalytics.$inferSelect;
export type Distribution = typeof distribution.$inferSelect;
export type VipServices = typeof vipServices.$inferSelect;

export type InsertArtist = z.infer<typeof insertArtistSchema>;
export type InsertAlbum = z.infer<typeof insertAlbumSchema>;
export type InsertTrack = z.infer<typeof insertTrackSchema>;
export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;
export type InsertPlaylistTrack = z.infer<typeof insertPlaylistTrackSchema>;
export type InsertStudioSession = z.infer<typeof insertStudioSessionSchema>;
export type InsertLicense = z.infer<typeof insertLicenseSchema>;
export type InsertCollaboration = z.infer<typeof insertCollaborationSchema>;
export type InsertStreamingStats = z.infer<typeof insertStreamingStatsSchema>;
export type InsertIpProtection = z.infer<typeof insertIpProtectionSchema>;
export type InsertCrossPlatformAnalytics = z.infer<typeof insertCrossPlatformAnalyticsSchema>;
export type InsertDistribution = z.infer<typeof insertDistributionSchema>;
export type InsertVipServices = z.infer<typeof insertVipServicesSchema>;

export interface TrackWithArtist extends Track {
  artist: Artist;
  album?: Album;
  collaborations?: Collaboration[];
  stats?: StreamingStats;
  ipProtection?: IpProtection;
  crossPlatformStats?: CrossPlatformAnalytics[];
}

export interface AlbumWithArtist extends Album {
  artist: Artist;
}

export interface IpProtectionWithTrack extends IpProtection {
  track: TrackWithArtist;
  artist: Artist;
}

export interface CrossPlatformAnalyticsWithTrack extends CrossPlatformAnalytics {
  track: TrackWithArtist;
  artist: Artist;
}

export interface PlaylistWithTracks extends Playlist {
  tracks: TrackWithArtist[];
}

export interface StudioSessionWithArtist extends StudioSession {
  artist: Artist;
}

export interface CollaborationWithArtist extends Collaboration {
  artist: Artist;
  track: Track;
}

export interface LicenseWithTrack extends License {
  track: TrackWithArtist;
}
