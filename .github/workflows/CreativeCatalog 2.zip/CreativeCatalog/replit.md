# Replit Configuration for Music Streaming Application

## Overview

This is a comprehensive music streaming and licensing platform built for B•B Studios. The application combines Spotify-like streaming functionality with Artlist-style licensing features, allowing artists to showcase their music, book studio sessions, license tracks, and collaborate on projects. Built with a modern TypeScript stack, the platform supports music streaming, artist management, studio booking, audio licensing, collaboration tracking, revenue analytics, and AI-powered automatic distribution to major streaming platforms.

### VIP Distribution Service
The platform's flagship feature is the VIP Distribution System - when artists record and produce music at B•B Studios' physical facility, their tracks are automatically uploaded to the B•B platform under the label and distributed to major streaming platforms (Spotify, Apple Music, YouTube Music) using AI-powered optimization. The system generates optimized metadata, descriptions, and marketing materials using OpenAI's latest models, ensuring maximum discoverability and engagement across platforms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with hot module replacement
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Style**: RESTful APIs with Express routes
- **Middleware**: Built-in Express middleware for JSON parsing and CORS handling
- **Error Handling**: Centralized error handling middleware

### Database Layer
- **ORM**: Drizzle ORM for type-safe database interactions
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema Management**: Shared schema definitions between client and server
- **Migrations**: Drizzle Kit for database migrations

## Key Components

### Shared Schema
Located in `shared/schema.ts`, this defines the comprehensive data models for:
- Artists (with bio, image, emoji)
- Albums (linked to artists)
- Tracks (with enhanced metadata: duration, genre, audio URLs, BPM, key, mood, tags, licensing info)
- Playlists and playlist-track relationships
- Studio Sessions (for booking and management)
- Licenses (for track licensing and revenue tracking)
- Collaborations (for artist collaboration tracking)
- Streaming Stats (for analytics and performance metrics)
- Zod schemas for runtime validation

### Enhanced Features
- **Physical Studio Booking System**: Real recording studio facility booking with professional equipment (Neumann mics, Pro Tools HDX, SSL pre-amps)
- **Music Licensing Platform**: Tracks can be licensed for commercial use with different license types and pricing tiers
- **Collaboration Tracking**: Artists can collaborate on tracks with role and contribution tracking
- **Analytics Dashboard**: Comprehensive streaming statistics and revenue reporting across multiple platforms
- **IP Protection Services**: Copyright registration, ISRC codes, publishing rights management, and territorial rights tracking
- **Cross-Platform Analytics**: Track performance on Spotify, Apple Music, YouTube, and other streaming platforms
- **Revenue Management**: Track licensing sales, streaming royalties, and artist revenue sharing
- **Studio Services**: On-site engineering, mixing/mastering, and professional equipment rental
- **Advanced Search**: Filter tracks by mood, tags, BPM, key, and genre
- **Copyright Management**: Automated IP protection workflows for tracks recorded at B•B Studios
- **VIP AI Distribution System**: Automatic distribution to major streaming platforms (Spotify, Apple Music, YouTube Music) with AI-powered metadata optimization for artists recording at the studio
- **Label Management**: Complete record label functionality for B•B Studios with artist signing, revenue sharing, and comprehensive VIP services

### Audio System
- Custom audio player hook (`use-audio-player.tsx`) for managing playback state
- Audio utilities for time formatting and waveform generation
- Web Audio API integration for advanced audio features
- Visual waveform components for track representation

### UI System
- Comprehensive component library based on Radix UI
- Custom theming with B•B Studios brand colors (purple, pink, green)
- Dark theme as default with CSS custom properties
- Responsive design with mobile-first approach

### Storage Layer
- Abstract storage interface (`IStorage`) for data operations
- CRUD operations for all music entities
- Search functionality for tracks
- Playlist management capabilities

## Data Flow

1. **Client Requests**: React components use TanStack Query to fetch data
2. **API Routes**: Express routes handle HTTP requests and validate input
3. **Data Layer**: Drizzle ORM queries PostgreSQL database
4. **Response**: JSON responses sent back through Express middleware
5. **State Updates**: TanStack Query manages caching and background updates
6. **UI Updates**: React components re-render based on query state changes

## External Dependencies

### Core Framework Dependencies
- React ecosystem (React, React DOM, React Query)
- Express.js for server framework
- Drizzle ORM with PostgreSQL adapter
- Vite for build tooling and development server

### UI and Styling
- Radix UI component primitives for accessibility
- Tailwind CSS for utility-first styling
- Lucide React for icons
- Class Variance Authority for component variants

### Development Tools
- TypeScript for type safety
- Zod for runtime schema validation
- ESBuild for production builds
- TSX for TypeScript execution in development

### Database and Hosting
- Neon Database for serverless PostgreSQL
- Designed for Replit hosting environment

## Deployment Strategy

### Development Mode
- Vite dev server serves the React application
- TSX runs the Express server with hot reloading
- Both frontend and backend run concurrently
- Database migrations applied via Drizzle Kit

### Production Build
1. Vite builds the React app to `dist/public`
2. ESBuild bundles the Express server to `dist/index.js`
3. Static files served through Express in production
4. Single entry point for deployment

### Environment Configuration
- Development: Uses Vite middleware for HMR
- Production: Express serves static files from build directory
- Database URL configured via environment variables
- Replit-specific optimizations included

The application is designed to work seamlessly in the Replit environment with proper build scripts and development tooling configured for the platform.