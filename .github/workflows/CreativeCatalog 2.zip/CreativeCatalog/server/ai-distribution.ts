import OpenAI from "openai";
import type { Distribution, Track, Artist } from "@shared/schema";

// Initialize OpenAI client - only if API key is available
let openai: OpenAI | null = null;

if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ 
    apiKey: process.env.OPENAI_API_KEY 
  });
}

export interface AIMetadata {
  optimizedTitle: string;
  description: string;
  tags: string[];
  genre: string;
  mood: string;
  spotifyDescription: string;
  appleMusicDescription: string;
  youtubeDescription: string;
  releaseStrategy: {
    optimalReleaseDate: string;
    marketingKeywords: string[];
    targetAudience: string;
  };
}

export interface DistributionPlatform {
  name: string;
  apiEndpoint?: string;
  enabled: boolean;
  metadata: Record<string, any>;
}

export class AIDistributionService {
  private platforms: DistributionPlatform[] = [
    {
      name: 'spotify',
      enabled: true,
      metadata: { requiresISRC: true, supportsCoverArt: true }
    },
    {
      name: 'apple-music',
      enabled: true,
      metadata: { requiresUPC: true, supportsCoverArt: true }
    },
    {
      name: 'youtube-music',
      enabled: true,
      metadata: { requiresContentID: true, supportsCoverArt: true }
    },
    {
      name: 'amazon-music',
      enabled: true,
      metadata: { requiresUPC: true, supportsCoverArt: true }
    }
  ];

  /**
   * Generate AI-optimized metadata for a track using OpenAI
   */
  async generateOptimizedMetadata(track: Track, artist: Artist): Promise<AIMetadata> {
    if (!openai) {
      throw new Error("OpenAI API key not configured. Please add OPENAI_API_KEY to your environment variables.");
    }

    try {
      const prompt = `
        As an expert music marketing strategist for B•B Studios record label, create optimized metadata for a track being distributed to streaming platforms.

        Track Info:
        - Title: ${track.title}
        - Artist: ${artist.name}
        - Genre: ${track.genre || 'Not specified'}
        - BPM: ${track.bpm || 'Not specified'}
        - Key: ${track.musicalKey || 'Not specified'}
        - Mood: ${track.mood || 'Not specified'}
        - Tags: ${track.tags?.join(', ') || 'Not specified'}
        - Artist Bio: ${artist.bio}

        B•B Studios specializes in kink-pop, trap noir, and seductive rebellion music. The label represents artists like La Maladita, SavageBEN, C E L L O, and Alessia Rimes.

        Generate optimized metadata that will maximize discoverability and engagement across streaming platforms. Return JSON format with these fields:
        - optimizedTitle: Enhanced version of track title for SEO
        - description: General description for streaming platforms (150 words max)
        - tags: Array of relevant hashtags and keywords (10-15 tags)
        - genre: Primary genre classification
        - mood: Primary mood/vibe
        - spotifyDescription: Spotify-specific description (100 words max)
        - appleMusicDescription: Apple Music-specific description (100 words max)  
        - youtubeDescription: YouTube Music-specific description with hashtags (200 words max)
        - releaseStrategy: Object with optimalReleaseDate (suggest based on current trends), marketingKeywords array, and targetAudience string
      `;

      const response = await openai!.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an expert music marketing strategist specializing in streaming platform optimization and B•B Studios' kink-pop/trap noir aesthetic. Return valid JSON only."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 1000,
      });

      const aiMetadata = JSON.parse(response.choices[0].message.content || '{}');
      return aiMetadata;

    } catch (error) {
      console.error('Error generating AI metadata:', error);
      // Return fallback metadata if AI fails
      return {
        optimizedTitle: track.title,
        description: `${track.title} by ${artist.name} - A captivating track from B•B Studios featuring the signature sound that defines modern alternative music.`,
        tags: ['music', 'alternative', 'bb-studios', track.genre || 'indie'].filter(Boolean),
        genre: track.genre || 'Alternative',
        mood: track.mood || 'Energetic',
        spotifyDescription: `${track.title} by ${artist.name} - Experience the unique sound of B•B Studios.`,
        appleMusicDescription: `${track.title} by ${artist.name} - A standout track showcasing artistic innovation.`,
        youtubeDescription: `${track.title} by ${artist.name}\n\nStream on all platforms: B•B Studios\n\n#music #alternative #${track.genre?.toLowerCase().replace(/\s+/g, '') || 'indie'}`,
        releaseStrategy: {
          optimalReleaseDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 1 week from now
          marketingKeywords: ['music', 'alternative', track.genre || 'indie'],
          targetAudience: 'Alternative music enthusiasts aged 18-35'
        }
      };
    }
  }

  /**
   * Simulate distribution to streaming platforms
   * In a real implementation, this would make API calls to each platform
   */
  async distributeToStreamingPlatforms(
    track: Track, 
    artist: Artist, 
    aiMetadata: AIMetadata,
    platforms: string[]
  ): Promise<{
    platform: string;
    status: 'success' | 'failed' | 'pending';
    distributionId?: string;
    message: string;
  }[]> {
    const results = [];

    for (const platformName of platforms) {
      const platform = this.platforms.find(p => p.name === platformName);
      
      if (!platform || !platform.enabled) {
        results.push({
          platform: platformName,
          status: 'failed' as const,
          message: `Platform ${platformName} not available`
        });
        continue;
      }

      try {
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 1000));

        // Simulate successful distribution
        const distributionId = `${platformName}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        results.push({
          platform: platformName,
          status: 'success' as const,
          distributionId,
          message: `Successfully distributed to ${platformName}. Track will be live within 24-48 hours.`
        });

        console.log(`✓ Distributed "${track.title}" by ${artist.name} to ${platformName}`);
        console.log(`  - Optimized title: ${aiMetadata.optimizedTitle}`);
        console.log(`  - Distribution ID: ${distributionId}`);

      } catch (error) {
        results.push({
          platform: platformName,
          status: 'failed' as const,
          message: `Failed to distribute to ${platformName}: ${error.message}`
        });
      }
    }

    return results;
  }

  /**
   * Generate catalog number for B•B Studios releases
   */
  generateCatalogNumber(artistName: string, trackTitle: string): string {
    const year = new Date().getFullYear();
    const artistInitials = artistName.split(' ').map(word => word.charAt(0)).join('').toUpperCase();
    const trackInitials = trackTitle.split(' ').map(word => word.charAt(0)).join('').toUpperCase();
    const sequence = Math.floor(Math.random() * 999) + 1;
    
    return `BB${year}${artistInitials}${trackInitials}${sequence.toString().padStart(3, '0')}`;
  }

  /**
   * Generate UPC (Universal Product Code) for releases
   */
  generateUPC(): string {
    // UPC format: 12 digits starting with B•B Studios prefix
    const prefix = '123456'; // In real implementation, use registered UPC prefix
    const sequence = Math.floor(Math.random() * 999999).toString().padStart(6, '0');
    return prefix + sequence;
  }

  /**
   * Complete distribution process for a VIP service
   */
  async processVIPDistribution(
    track: Track,
    artist: Artist,
    platforms: string[] = ['spotify', 'apple-music', 'youtube-music']
  ): Promise<{
    success: boolean;
    distributionId: string;
    aiMetadata: AIMetadata;
    platformResults: any[];
    catalogNumber: string;
    upc: string;
  }> {
    try {
      console.log(`🎵 Starting VIP distribution for "${track.title}" by ${artist.name}`);

      // Generate AI-optimized metadata
      const aiMetadata = await this.generateOptimizedMetadata(track, artist);
      console.log('✓ Generated AI-optimized metadata');

      // Generate catalog number and UPC
      const catalogNumber = this.generateCatalogNumber(artist.name, track.title);
      const upc = this.generateUPC();

      // Distribute to platforms
      const platformResults = await this.distributeToStreamingPlatforms(
        track, 
        artist, 
        aiMetadata,
        platforms
      );

      const successfulDistributions = platformResults.filter(r => r.status === 'success').length;
      const distributionId = `BB_DIST_${Date.now()}`;

      console.log(`✓ Distribution complete: ${successfulDistributions}/${platforms.length} platforms successful`);

      return {
        success: successfulDistributions > 0,
        distributionId,
        aiMetadata,
        platformResults,
        catalogNumber,
        upc
      };

    } catch (error) {
      console.error('VIP distribution failed:', error);
      throw error;
    }
  }
}

export const aiDistributionService = new AIDistributionService();