import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertArtistSchema, insertAlbumSchema, insertTrackSchema, insertPlaylistSchema, insertDistributionSchema, insertVipServicesSchema } from "@shared/schema";
import { aiDistributionService } from "./ai-distribution";

export async function registerRoutes(app: Express): Promise<Server> {
  // Artists
  app.get("/api/artists", async (req, res) => {
    try {
      const artists = await storage.getArtists();
      res.json(artists);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artists" });
    }
  });

  app.get("/api/artists/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const artist = await storage.getArtist(id);
      
      if (!artist) {
        return res.status(404).json({ message: "Artist not found" });
      }
      
      res.json(artist);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artist" });
    }
  });

  app.post("/api/artists", async (req, res) => {
    try {
      const artistData = insertArtistSchema.parse(req.body);
      const artist = await storage.createArtist(artistData);
      res.status(201).json(artist);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid artist data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create artist" });
    }
  });

  // Albums
  app.get("/api/albums", async (req, res) => {
    try {
      const albums = await storage.getAlbums();
      res.json(albums);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch albums" });
    }
  });

  app.get("/api/albums/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const album = await storage.getAlbum(id);
      
      if (!album) {
        return res.status(404).json({ message: "Album not found" });
      }
      
      res.json(album);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch album" });
    }
  });

  app.get("/api/artists/:artistId/albums", async (req, res) => {
    try {
      const artistId = parseInt(req.params.artistId);
      const albums = await storage.getAlbumsByArtist(artistId);
      res.json(albums);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artist albums" });
    }
  });

  // Tracks
  app.get("/api/tracks", async (req, res) => {
    try {
      const tracks = await storage.getTracks();
      res.json(tracks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tracks" });
    }
  });

  app.get("/api/tracks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const track = await storage.getTrack(id);
      
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      
      res.json(track);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch track" });
    }
  });

  app.get("/api/artists/:artistId/tracks", async (req, res) => {
    try {
      const artistId = parseInt(req.params.artistId);
      const tracks = await storage.getTracksByArtist(artistId);
      res.json(tracks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artist tracks" });
    }
  });

  app.get("/api/albums/:albumId/tracks", async (req, res) => {
    try {
      const albumId = parseInt(req.params.albumId);
      const tracks = await storage.getTracksByAlbum(albumId);
      res.json(tracks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch album tracks" });
    }
  });

  app.get("/api/search/tracks", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const tracks = await storage.searchTracks(query);
      res.json(tracks);
    } catch (error) {
      res.status(500).json({ message: "Failed to search tracks" });
    }
  });

  app.get("/api/genres/:genre/tracks", async (req, res) => {
    try {
      const genre = req.params.genre;
      const tracks = await storage.getTracksByGenre(genre);
      res.json(tracks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tracks by genre" });
    }
  });

  app.patch("/api/tracks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const track = await storage.updateTrack(id, updates);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      
      res.json(track);
    } catch (error) {
      res.status(500).json({ message: "Failed to update track" });
    }
  });

  // Playlists
  app.get("/api/playlists", async (req, res) => {
    try {
      const playlists = await storage.getPlaylists();
      res.json(playlists);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch playlists" });
    }
  });

  app.get("/api/playlists/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const playlist = await storage.getPlaylist(id);
      
      if (!playlist) {
        return res.status(404).json({ message: "Playlist not found" });
      }
      
      res.json(playlist);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch playlist" });
    }
  });

  app.post("/api/playlists", async (req, res) => {
    try {
      const playlistData = insertPlaylistSchema.parse(req.body);
      const playlist = await storage.createPlaylist(playlistData);
      res.status(201).json(playlist);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid playlist data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create playlist" });
    }
  });

  app.post("/api/playlists/:id/tracks/:trackId", async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const trackId = parseInt(req.params.trackId);
      
      await storage.addTrackToPlaylist(playlistId, trackId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to add track to playlist" });
    }
  });

  app.delete("/api/playlists/:id/tracks/:trackId", async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const trackId = parseInt(req.params.trackId);
      
      await storage.removeTrackFromPlaylist(playlistId, trackId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove track from playlist" });
    }
  });

  // AI Distribution System Routes
  app.get("/api/distributions", async (req, res) => {
    try {
      const distributions = await storage.getDistributions();
      res.json(distributions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch distributions" });
    }
  });

  app.get("/api/distributions/track/:trackId", async (req, res) => {
    try {
      const trackId = parseInt(req.params.trackId);
      const distributions = await storage.getDistributionsByTrack(trackId);
      res.json(distributions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch track distributions" });
    }
  });

  // VIP Distribution Service - Process automatic distribution
  app.post("/api/vip/distribute", async (req, res) => {
    try {
      const { trackId, artistId, platforms } = req.body;
      
      if (!trackId || !artistId) {
        return res.status(400).json({ message: "Track ID and Artist ID are required" });
      }

      // Get track and artist data
      const track = await storage.getTrack(trackId);
      const artist = await storage.getArtist(artistId);

      if (!track || !artist) {
        return res.status(404).json({ message: "Track or artist not found" });
      }

      // Process VIP distribution using AI
      const distributionResult = await aiDistributionService.processVIPDistribution(
        track,
        artist,
        platforms || ['spotify', 'apple-music', 'youtube-music']
      );

      // Save distribution record
      const distribution = await storage.createDistribution({
        trackId: trackId,
        artistId: artistId,
        distributionStatus: distributionResult.success ? 'distributed' : 'failed',
        platforms: platforms || ['spotify', 'apple-music', 'youtube-music'],
        aiGeneratedMetadata: distributionResult.aiMetadata,
        distributionDate: new Date(),
        releaseDate: new Date(distributionResult.aiMetadata.releaseStrategy.optimalReleaseDate),
        labelName: 'B•B Studios',
        upc: distributionResult.upc,
        catalogNumber: distributionResult.catalogNumber,
        distributionFee: '99.99',
        revenueShare: '70.00', // 70% to artist, 30% to label
        notes: `AI-powered distribution: ${distributionResult.platformResults.length} platforms processed`
      });

      // Create VIP service record
      await storage.createVipService({
        artistId: artistId,
        serviceType: 'distribution',
        trackId: trackId,
        status: 'completed',
        serviceDate: new Date(),
        completionDate: new Date(),
        aiDistributionEnabled: true,
        labelSigningStatus: 'signed',
        packagePrice: '199.99',
        notes: `Full VIP distribution package - AI optimized for ${platforms?.join(', ') || 'all platforms'}`
      });

      res.json({
        success: distributionResult.success,
        distribution,
        platformResults: distributionResult.platformResults,
        aiMetadata: distributionResult.aiMetadata,
        message: `Track "${track.title}" by ${artist.name} has been distributed to ${distributionResult.platformResults.filter(r => r.status === 'success').length} platforms successfully.`
      });

    } catch (error) {
      console.error('VIP distribution error:', error);
      res.status(500).json({ 
        message: error.message || "Failed to process VIP distribution",
        error: error.message
      });
    }
  });

  // VIP Services Routes
  app.get("/api/vip/services", async (req, res) => {
    try {
      const services = await storage.getVipServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch VIP services" });
    }
  });

  app.get("/api/vip/services/artist/:artistId", async (req, res) => {
    try {
      const artistId = parseInt(req.params.artistId);
      const services = await storage.getVipServicesByArtist(artistId);
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artist VIP services" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
