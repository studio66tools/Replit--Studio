import { 
  artists, 
  albums, 
  tracks, 
  playlists, 
  playlistTracks,
  studioSessions,
  licenses,
  collaborations,
  streamingStats,
  distribution,
  vipServices,
  type Artist, 
  type Album, 
  type Track, 
  type Playlist, 
  type PlaylistTrack,
  type StudioSession,
  type License,
  type Collaboration,
  type StreamingStats,
  type Distribution,
  type VipServices,
  type InsertArtist, 
  type InsertAlbum, 
  type InsertTrack, 
  type InsertPlaylist, 
  type InsertPlaylistTrack,
  type InsertStudioSession,
  type InsertLicense,
  type InsertCollaboration,
  type InsertStreamingStats,
  type InsertDistribution,
  type InsertVipServices,
  type TrackWithArtist,
  type AlbumWithArtist,
  type PlaylistWithTracks,
  type StudioSessionWithArtist,
  type LicenseWithTrack,
  type CollaborationWithArtist
} from "@shared/schema";

export interface IStorage {
  // Artists
  getArtists(): Promise<Artist[]>;
  getArtist(id: number): Promise<Artist | undefined>;
  createArtist(artist: InsertArtist): Promise<Artist>;

  // Albums
  getAlbums(): Promise<AlbumWithArtist[]>;
  getAlbum(id: number): Promise<AlbumWithArtist | undefined>;
  getAlbumsByArtist(artistId: number): Promise<AlbumWithArtist[]>;
  createAlbum(album: InsertAlbum): Promise<Album>;

  // Tracks
  getTracks(): Promise<TrackWithArtist[]>;
  getTrack(id: number): Promise<TrackWithArtist | undefined>;
  getTracksByArtist(artistId: number): Promise<TrackWithArtist[]>;
  getTracksByAlbum(albumId: number): Promise<TrackWithArtist[]>;
  getTracksByGenre(genre: string): Promise<TrackWithArtist[]>;
  getTracksByMood(mood: string): Promise<TrackWithArtist[]>;
  getTracksByTags(tags: string[]): Promise<TrackWithArtist[]>;
  searchTracks(query: string, filters?: { mood?: string; tags?: string[]; bpm?: number; key?: string }): Promise<TrackWithArtist[]>;
  createTrack(track: InsertTrack): Promise<Track>;
  updateTrack(id: number, updates: Partial<Track>): Promise<Track | undefined>;
  incrementPlayCount(trackId: number): Promise<void>;
  incrementDownloadCount(trackId: number): Promise<void>;

  // Playlists
  getPlaylists(): Promise<Playlist[]>;
  getPlaylist(id: number): Promise<PlaylistWithTracks | undefined>;
  createPlaylist(playlist: InsertPlaylist): Promise<Playlist>;
  addTrackToPlaylist(playlistId: number, trackId: number): Promise<void>;
  removeTrackFromPlaylist(playlistId: number, trackId: number): Promise<void>;

  // Studio Sessions
  getStudioSessions(): Promise<StudioSessionWithArtist[]>;
  getStudioSession(id: number): Promise<StudioSessionWithArtist | undefined>;
  getStudioSessionsByArtist(artistId: number): Promise<StudioSessionWithArtist[]>;
  createStudioSession(session: InsertStudioSession): Promise<StudioSession>;
  updateStudioSession(id: number, updates: Partial<StudioSession>): Promise<StudioSession | undefined>;

  // Licenses
  getLicenses(): Promise<LicenseWithTrack[]>;
  getLicense(id: number): Promise<LicenseWithTrack | undefined>;
  getLicensesByTrack(trackId: number): Promise<LicenseWithTrack[]>;
  createLicense(license: InsertLicense): Promise<License>;

  // Collaborations
  getCollaborations(): Promise<CollaborationWithArtist[]>;
  getCollaborationsByTrack(trackId: number): Promise<CollaborationWithArtist[]>;
  getCollaborationsByArtist(artistId: number): Promise<CollaborationWithArtist[]>;
  createCollaboration(collaboration: InsertCollaboration): Promise<Collaboration>;

  // Analytics
  getStreamingStats(trackId?: number, dateRange?: { start: Date; end: Date }): Promise<StreamingStats[]>;
  recordStreamingEvent(stats: InsertStreamingStats): Promise<StreamingStats>;
  getTopTracks(limit: number, timeframe?: 'day' | 'week' | 'month' | 'all'): Promise<TrackWithArtist[]>;
  getRevenueReport(artistId?: number, timeframe?: { start: Date; end: Date }): Promise<{ totalRevenue: number; trackBreakdown: { trackId: number; revenue: number }[] }>;

  // AI Distribution System
  getDistributions(): Promise<Distribution[]>;
  getDistribution(id: number): Promise<Distribution | undefined>;
  getDistributionsByTrack(trackId: number): Promise<Distribution[]>;
  getDistributionsByArtist(artistId: number): Promise<Distribution[]>;
  createDistribution(distribution: InsertDistribution): Promise<Distribution>;
  updateDistribution(id: number, updates: Partial<Distribution>): Promise<Distribution | undefined>;

  // VIP Services
  getVipServices(): Promise<VipServices[]>;
  getVipService(id: number): Promise<VipServices | undefined>;
  getVipServicesByArtist(artistId: number): Promise<VipServices[]>;
  createVipService(service: InsertVipServices): Promise<VipServices>;
  updateVipService(id: number, updates: Partial<VipServices>): Promise<VipServices | undefined>;
}

export class MemStorage implements IStorage {
  private artists: Map<number, Artist>;
  private albums: Map<number, Album>;
  private tracks: Map<number, Track>;
  private playlists: Map<number, Playlist>;
  private playlistTracks: Map<number, PlaylistTrack>;
  private studioSessions: Map<number, StudioSession>;
  private licenses: Map<number, License>;
  private collaborations: Map<number, Collaboration>;
  private streamingStats: Map<number, StreamingStats>;
  private distributions: Map<number, Distribution>;
  private vipServices: Map<number, VipServices>;
  private currentArtistId: number;
  private currentAlbumId: number;
  private currentTrackId: number;
  private currentPlaylistId: number;
  private currentPlaylistTrackId: number;
  private currentStudioSessionId: number;
  private currentLicenseId: number;
  private currentCollaborationId: number;
  private currentStreamingStatsId: number;
  private currentDistributionId: number;
  private currentVipServiceId: number;

  constructor() {
    this.artists = new Map();
    this.albums = new Map();
    this.tracks = new Map();
    this.playlists = new Map();
    this.playlistTracks = new Map();
    this.studioSessions = new Map();
    this.licenses = new Map();
    this.collaborations = new Map();
    this.streamingStats = new Map();
    this.distributions = new Map();
    this.vipServices = new Map();
    this.currentArtistId = 1;
    this.currentAlbumId = 1;
    this.currentTrackId = 1;
    this.currentPlaylistId = 1;
    this.currentPlaylistTrackId = 1;
    this.currentStudioSessionId = 1;
    this.currentLicenseId = 1;
    this.currentCollaborationId = 1;
    this.currentStreamingStatsId = 1;
    this.currentDistributionId = 1;
    this.currentVipServiceId = 1;

    this.seedData();
  }

  private seedData() {
    // Create artists
    const laMaladita = this.createArtistSync({
      name: "La Maladita",
      bio: "Femme fatale with fierce flow and unapologetic power",
      imageUrl: "https://pixabay.com/get/gfac8e121a773e63de45ca662a468cc5a794a737f7efef23fb6b80308246b1d20072dcdc2f956aecf95fb564d199aa2b8bf2f6ac2bc21578e1bf6c2a10daed056_1280.jpg",
      emoji: "🔥"
    });

    const savageBen = this.createArtistSync({
      name: "SavageBEN",
      bio: "Raw, fearless, and untamed",
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      emoji: "🔥"
    });

    const cello = this.createArtistSync({
      name: "CELLO",
      bio: "Producer & performer, creating hypnotic soundscapes",
      imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      emoji: "🎭"
    });

    const alessiaRimes = this.createArtistSync({
      name: "Alessia Rimes (RM)",
      bio: "Sensual, seductive, wrapped in silk & leather",
      imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      emoji: "🥀"
    });

    // Create albums
    const darkDesires = this.createAlbumSync({
      title: "Dark Desires",
      artistId: laMaladita.id,
      coverUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      releaseYear: 2024
    });

    const savageNights = this.createAlbumSync({
      title: "Savage Nights",
      artistId: savageBen.id,
      coverUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      releaseYear: 2024
    });

    const mindBending = this.createAlbumSync({
      title: "Mind Bending",
      artistId: cello.id,
      coverUrl: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      releaseYear: 2024
    });

    // Create tracks with enhanced metadata
    const track1 = this.createTrackSync({
      title: "Midnight Rebellion",
      artistId: laMaladita.id,
      albumId: darkDesires.id,
      duration: 204, // 3:24
      genre: "Kink-Pop",
      audioUrl: "https://www.soundjay.com/misc/sounds/dark-ambient-1.mp3",
      tags: ["dark", "seductive", "rebellion", "intense"],
      mood: "dark",
      bpm: 128,
      key: "Em",
      licenseType: "standard",
      licensePrice: "49.99",
      downloadEnabled: true,
      playCount: 1247,
      downloadCount: 23
    });

    const track2 = this.createTrackSync({
      title: "Untamed Frequencies",
      artistId: savageBen.id,
      albumId: savageNights.id,
      duration: 252, // 4:12
      genre: "Trap Noir",
      audioUrl: "https://www.soundjay.com/misc/sounds/dark-ambient-2.mp3",
      tags: ["urban", "aggressive", "raw", "underground"],
      mood: "aggressive",
      bpm: 140,
      key: "Dm",
      licenseType: "exclusive",
      licensePrice: "199.99",
      downloadEnabled: true,
      playCount: 892,
      downloadCount: 15
    });

    const track3 = this.createTrackSync({
      title: "Hypnotic Pulse",
      artistId: cello.id,
      albumId: mindBending.id,
      duration: 338, // 5:38
      genre: "Electronic",
      audioUrl: "https://www.soundjay.com/misc/sounds/dark-ambient-3.mp3",
      tags: ["hypnotic", "electronic", "experimental", "atmospheric"],
      mood: "hypnotic",
      bpm: 132,
      key: "Am",
      licenseType: "standard",
      licensePrice: "79.99",
      downloadEnabled: true,
      stemFilesUrl: "https://example.com/stems/hypnotic-pulse-stems.zip",
      playCount: 2156,
      downloadCount: 41
    });

    // Create playlists
    const darkVibes = this.createPlaylistSync({
      name: "Dark Vibes",
      description: "The darkest tracks from B•B Studios"
    });

    const kinkPopEssentials = this.createPlaylistSync({
      name: "Kink-Pop Essentials",
      description: "Essential kink-pop tracks"
    });

    const trapNoir = this.createPlaylistSync({
      name: "Trap Noir",
      description: "Dark urban vibes"
    });

    const seductiveRebellion = this.createPlaylistSync({
      name: "Seductive Rebellion",
      description: "Sultry rebellion anthems"
    });
  }

  private createArtistSync(artist: InsertArtist): Artist {
    const id = this.currentArtistId++;
    const newArtist: Artist = { ...artist, id };
    this.artists.set(id, newArtist);
    return newArtist;
  }

  private createAlbumSync(album: InsertAlbum): Album {
    const id = this.currentAlbumId++;
    const newAlbum: Album = { ...album, id };
    this.albums.set(id, newAlbum);
    return newAlbum;
  }

  private createTrackSync(track: InsertTrack): Track {
    const id = this.currentTrackId++;
    const newTrack: Track = { 
      ...track, 
      id, 
      isLiked: false,
      playCount: track.playCount || 0,
      downloadCount: track.downloadCount || 0,
      createdAt: new Date()
    };
    this.tracks.set(id, newTrack);
    return newTrack;
  }

  private createPlaylistSync(playlist: InsertPlaylist): Playlist {
    const id = this.currentPlaylistId++;
    const newPlaylist: Playlist = { ...playlist, id };
    this.playlists.set(id, newPlaylist);
    return newPlaylist;
  }

  async getArtists(): Promise<Artist[]> {
    return Array.from(this.artists.values());
  }

  async getArtist(id: number): Promise<Artist | undefined> {
    return this.artists.get(id);
  }

  async createArtist(artist: InsertArtist): Promise<Artist> {
    return this.createArtistSync(artist);
  }

  async getAlbums(): Promise<AlbumWithArtist[]> {
    const albums = Array.from(this.albums.values());
    return albums.map(album => ({
      ...album,
      artist: this.artists.get(album.artistId)!
    }));
  }

  async getAlbum(id: number): Promise<AlbumWithArtist | undefined> {
    const album = this.albums.get(id);
    if (!album) return undefined;
    
    return {
      ...album,
      artist: this.artists.get(album.artistId)!
    };
  }

  async getAlbumsByArtist(artistId: number): Promise<AlbumWithArtist[]> {
    const albums = Array.from(this.albums.values()).filter(a => a.artistId === artistId);
    return albums.map(album => ({
      ...album,
      artist: this.artists.get(album.artistId)!
    }));
  }

  async createAlbum(album: InsertAlbum): Promise<Album> {
    return this.createAlbumSync(album);
  }

  async getTracks(): Promise<TrackWithArtist[]> {
    const tracks = Array.from(this.tracks.values());
    return tracks.map(track => ({
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    }));
  }

  async getTrack(id: number): Promise<TrackWithArtist | undefined> {
    const track = this.tracks.get(id);
    if (!track) return undefined;

    return {
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    };
  }

  async getTracksByArtist(artistId: number): Promise<TrackWithArtist[]> {
    const tracks = Array.from(this.tracks.values()).filter(t => t.artistId === artistId);
    return tracks.map(track => ({
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    }));
  }

  async getTracksByAlbum(albumId: number): Promise<TrackWithArtist[]> {
    const tracks = Array.from(this.tracks.values()).filter(t => t.albumId === albumId);
    return tracks.map(track => ({
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    }));
  }

  async getTracksByGenre(genre: string): Promise<TrackWithArtist[]> {
    const tracks = Array.from(this.tracks.values()).filter(t => 
      t.genre?.toLowerCase().includes(genre.toLowerCase())
    );
    return tracks.map(track => ({
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    }));
  }

  async searchTracks(query: string, filters?: { mood?: string; tags?: string[]; bpm?: number; key?: string }): Promise<TrackWithArtist[]> {
    const lowerQuery = query.toLowerCase();
    const tracks = Array.from(this.tracks.values()).filter(track => {
      const artist = this.artists.get(track.artistId)!;
      const album = track.albumId ? this.albums.get(track.albumId) : undefined;
      
      // Text search
      const matchesQuery = track.title.toLowerCase().includes(lowerQuery) ||
                          artist.name.toLowerCase().includes(lowerQuery) ||
                          album?.title.toLowerCase().includes(lowerQuery) ||
                          track.genre?.toLowerCase().includes(lowerQuery) ||
                          track.tags?.some(tag => tag.toLowerCase().includes(lowerQuery));

      // Apply filters
      if (!matchesQuery) return false;
      if (filters?.mood && track.mood !== filters.mood) return false;
      if (filters?.key && track.key !== filters.key) return false;
      if (filters?.bpm && Math.abs((track.bpm || 0) - filters.bpm) > 5) return false;
      if (filters?.tags && !filters.tags.some(tag => track.tags?.includes(tag))) return false;

      return true;
    });

    return tracks.map(track => ({
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    }));
  }

  async getTracksByMood(mood: string): Promise<TrackWithArtist[]> {
    const tracks = Array.from(this.tracks.values()).filter(t => t.mood === mood);
    return tracks.map(track => ({
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    }));
  }

  async getTracksByTags(tags: string[]): Promise<TrackWithArtist[]> {
    const tracks = Array.from(this.tracks.values()).filter(t => 
      tags.some(tag => t.tags?.includes(tag))
    );
    return tracks.map(track => ({
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    }));
  }

  async incrementPlayCount(trackId: number): Promise<void> {
    const track = this.tracks.get(trackId);
    if (track) {
      track.playCount = (track.playCount || 0) + 1;
      this.tracks.set(trackId, track);
    }
  }

  async incrementDownloadCount(trackId: number): Promise<void> {
    const track = this.tracks.get(trackId);
    if (track) {
      track.downloadCount = (track.downloadCount || 0) + 1;
      this.tracks.set(trackId, track);
    }
  }

  async createTrack(track: InsertTrack): Promise<Track> {
    return this.createTrackSync(track);
  }

  async updateTrack(id: number, updates: Partial<Track>): Promise<Track | undefined> {
    const track = this.tracks.get(id);
    if (!track) return undefined;

    const updatedTrack = { ...track, ...updates };
    this.tracks.set(id, updatedTrack);
    return updatedTrack;
  }

  async getPlaylists(): Promise<Playlist[]> {
    return Array.from(this.playlists.values());
  }

  async getPlaylist(id: number): Promise<PlaylistWithTracks | undefined> {
    const playlist = this.playlists.get(id);
    if (!playlist) return undefined;

    const playlistTrackEntries = Array.from(this.playlistTracks.values())
      .filter(pt => pt.playlistId === id)
      .sort((a, b) => a.position - b.position);

    const tracks = playlistTrackEntries.map(pt => {
      const track = this.tracks.get(pt.trackId)!;
      return {
        ...track,
        artist: this.artists.get(track.artistId)!,
        album: track.albumId ? this.albums.get(track.albumId) : undefined
      };
    });

    return { ...playlist, tracks };
  }

  async createPlaylist(playlist: InsertPlaylist): Promise<Playlist> {
    return this.createPlaylistSync(playlist);
  }

  async addTrackToPlaylist(playlistId: number, trackId: number): Promise<void> {
    const existingTracks = Array.from(this.playlistTracks.values())
      .filter(pt => pt.playlistId === playlistId);
    
    const position = existingTracks.length;
    const id = this.currentPlaylistTrackId++;
    
    this.playlistTracks.set(id, {
      id,
      playlistId,
      trackId,
      position
    });
  }

  async removeTrackFromPlaylist(playlistId: number, trackId: number): Promise<void> {
    const entries = Array.from(this.playlistTracks.entries());
    const entryToRemove = entries.find(([_, pt]) => 
      pt.playlistId === playlistId && pt.trackId === trackId
    );
    
    if (entryToRemove) {
      this.playlistTracks.delete(entryToRemove[0]);
    }
  }

  // Studio Sessions Methods
  async getStudioSessions(): Promise<StudioSessionWithArtist[]> {
    const sessions = Array.from(this.studioSessions.values());
    return sessions.map(session => ({
      ...session,
      artist: this.artists.get(session.artistId)!
    }));
  }

  async getStudioSession(id: number): Promise<StudioSessionWithArtist | undefined> {
    const session = this.studioSessions.get(id);
    if (!session) return undefined;
    return {
      ...session,
      artist: this.artists.get(session.artistId)!
    };
  }

  async getStudioSessionsByArtist(artistId: number): Promise<StudioSessionWithArtist[]> {
    const sessions = Array.from(this.studioSessions.values()).filter(s => s.artistId === artistId);
    return sessions.map(session => ({
      ...session,
      artist: this.artists.get(session.artistId)!
    }));
  }

  async createStudioSession(session: InsertStudioSession): Promise<StudioSession> {
    const id = this.currentStudioSessionId++;
    const newSession: StudioSession = { 
      ...session, 
      id,
      createdAt: new Date()
    };
    this.studioSessions.set(id, newSession);
    return newSession;
  }

  async updateStudioSession(id: number, updates: Partial<StudioSession>): Promise<StudioSession | undefined> {
    const session = this.studioSessions.get(id);
    if (!session) return undefined;
    const updatedSession = { ...session, ...updates };
    this.studioSessions.set(id, updatedSession);
    return updatedSession;
  }

  // License Methods
  async getLicenses(): Promise<LicenseWithTrack[]> {
    const licenses = Array.from(this.licenses.values());
    return licenses.map(license => ({
      ...license,
      track: this.getTrackWithArtist(license.trackId)!
    }));
  }

  async getLicense(id: number): Promise<LicenseWithTrack | undefined> {
    const license = this.licenses.get(id);
    if (!license) return undefined;
    return {
      ...license,
      track: this.getTrackWithArtist(license.trackId)!
    };
  }

  async getLicensesByTrack(trackId: number): Promise<LicenseWithTrack[]> {
    const licenses = Array.from(this.licenses.values()).filter(l => l.trackId === trackId);
    return licenses.map(license => ({
      ...license,
      track: this.getTrackWithArtist(license.trackId)!
    }));
  }

  async createLicense(license: InsertLicense): Promise<License> {
    const id = this.currentLicenseId++;
    const newLicense: License = { 
      ...license, 
      id,
      purchaseDate: new Date()
    };
    this.licenses.set(id, newLicense);
    return newLicense;
  }

  // Collaboration Methods
  async getCollaborations(): Promise<CollaborationWithArtist[]> {
    const collaborations = Array.from(this.collaborations.values());
    return collaborations.map(collaboration => ({
      ...collaboration,
      artist: this.artists.get(collaboration.artistId)!,
      track: this.tracks.get(collaboration.trackId)!
    }));
  }

  async getCollaborationsByTrack(trackId: number): Promise<CollaborationWithArtist[]> {
    const collaborations = Array.from(this.collaborations.values()).filter(c => c.trackId === trackId);
    return collaborations.map(collaboration => ({
      ...collaboration,
      artist: this.artists.get(collaboration.artistId)!,
      track: this.tracks.get(collaboration.trackId)!
    }));
  }

  async getCollaborationsByArtist(artistId: number): Promise<CollaborationWithArtist[]> {
    const collaborations = Array.from(this.collaborations.values()).filter(c => c.artistId === artistId);
    return collaborations.map(collaboration => ({
      ...collaboration,
      artist: this.artists.get(collaboration.artistId)!,
      track: this.tracks.get(collaboration.trackId)!
    }));
  }

  async createCollaboration(collaboration: InsertCollaboration): Promise<Collaboration> {
    const id = this.currentCollaborationId++;
    const newCollaboration: Collaboration = { 
      ...collaboration, 
      id,
      createdAt: new Date()
    };
    this.collaborations.set(id, newCollaboration);
    return newCollaboration;
  }

  // Analytics Methods
  async getStreamingStats(trackId?: number, dateRange?: { start: Date; end: Date }): Promise<StreamingStats[]> {
    let stats = Array.from(this.streamingStats.values());
    
    if (trackId) {
      stats = stats.filter(s => s.trackId === trackId);
    }
    
    if (dateRange) {
      stats = stats.filter(s => 
        s.date && s.date >= dateRange.start && s.date <= dateRange.end
      );
    }
    
    return stats;
  }

  async recordStreamingEvent(stats: InsertStreamingStats): Promise<StreamingStats> {
    const id = this.currentStreamingStatsId++;
    const newStats: StreamingStats = { 
      ...stats, 
      id,
      date: new Date()
    };
    this.streamingStats.set(id, newStats);
    return newStats;
  }

  async getTopTracks(limit: number, timeframe: 'day' | 'week' | 'month' | 'all' = 'all'): Promise<TrackWithArtist[]> {
    const tracks = Array.from(this.tracks.values())
      .sort((a, b) => (b.playCount || 0) - (a.playCount || 0))
      .slice(0, limit);
    
    return tracks.map(track => ({
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    }));
  }

  async getRevenueReport(artistId?: number, timeframe?: { start: Date; end: Date }): Promise<{ totalRevenue: number; trackBreakdown: { trackId: number; revenue: number }[] }> {
    let licenses = Array.from(this.licenses.values());
    
    if (artistId) {
      const artistTracks = Array.from(this.tracks.values())
        .filter(t => t.artistId === artistId)
        .map(t => t.id);
      licenses = licenses.filter(l => artistTracks.includes(l.trackId));
    }
    
    if (timeframe) {
      licenses = licenses.filter(l => 
        l.purchaseDate && l.purchaseDate >= timeframe.start && l.purchaseDate <= timeframe.end
      );
    }
    
    const totalRevenue = licenses.reduce((sum, license) => 
      sum + parseFloat(license.price.toString()), 0
    );
    
    const trackBreakdown = licenses.reduce((acc, license) => {
      const existing = acc.find(item => item.trackId === license.trackId);
      if (existing) {
        existing.revenue += parseFloat(license.price.toString());
      } else {
        acc.push({ trackId: license.trackId, revenue: parseFloat(license.price.toString()) });
      }
      return acc;
    }, [] as { trackId: number; revenue: number }[]);
    
    return { totalRevenue, trackBreakdown };
  }

  // AI Distribution System Methods
  async getDistributions(): Promise<Distribution[]> {
    return Array.from(this.distributions.values());
  }

  async getDistribution(id: number): Promise<Distribution | undefined> {
    return this.distributions.get(id);
  }

  async getDistributionsByTrack(trackId: number): Promise<Distribution[]> {
    return Array.from(this.distributions.values()).filter(d => d.trackId === trackId);
  }

  async getDistributionsByArtist(artistId: number): Promise<Distribution[]> {
    return Array.from(this.distributions.values()).filter(d => d.artistId === artistId);
  }

  async createDistribution(distribution: InsertDistribution): Promise<Distribution> {
    const id = this.currentDistributionId++;
    const newDistribution: Distribution = {
      id,
      ...distribution,
      createdAt: new Date()
    };
    this.distributions.set(id, newDistribution);
    return newDistribution;
  }

  async updateDistribution(id: number, updates: Partial<Distribution>): Promise<Distribution | undefined> {
    const distribution = this.distributions.get(id);
    if (!distribution) return undefined;
    const updated = { ...distribution, ...updates };
    this.distributions.set(id, updated);
    return updated;
  }

  // VIP Services Methods
  async getVipServices(): Promise<VipServices[]> {
    return Array.from(this.vipServices.values());
  }

  async getVipService(id: number): Promise<VipServices | undefined> {
    return this.vipServices.get(id);
  }

  async getVipServicesByArtist(artistId: number): Promise<VipServices[]> {
    return Array.from(this.vipServices.values()).filter(v => v.artistId === artistId);
  }

  async createVipService(service: InsertVipServices): Promise<VipServices> {
    const id = this.currentVipServiceId++;
    const newService: VipServices = {
      id,
      ...service,
      createdAt: new Date()
    };
    this.vipServices.set(id, newService);
    return newService;
  }

  async updateVipService(id: number, updates: Partial<VipServices>): Promise<VipServices | undefined> {
    const service = this.vipServices.get(id);
    if (!service) return undefined;
    const updated = { ...service, ...updates };
    this.vipServices.set(id, updated);
    return updated;
  }

  private getTrackWithArtist(trackId: number): TrackWithArtist | undefined {
    const track = this.tracks.get(trackId);
    if (!track) return undefined;
    return {
      ...track,
      artist: this.artists.get(track.artistId)!,
      album: track.albumId ? this.albums.get(track.albumId) : undefined
    };
  }
}

export const storage = new MemStorage();
